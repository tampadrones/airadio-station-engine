# Troubleshooting

## Services not healthy

```bash
docker compose ps
docker compose logs -f --tail=200 app
docker compose logs -f --tail=200 ssh
docker compose logs -f --tail=200 db
docker compose logs -f --tail=200 redis
```

## SSH port 2222 is already in use

If you previously ran an older Compose config (service name `game`), you may have an orphan container still binding `2222`.

Options:
- Change `.env` `OPERATORNET_SSH_PORT` to a free port, or
- Clean up old containers:

```bash
docker compose down --remove-orphans
docker compose up -d --build
```

## SSH connects but immediately disconnects

Common causes:
- No matching OS account inside the `ssh` container
- Player is missing/disabled in the DB (SSH entrypoint requires pre-created players)

Fix:
1. Create player:

```bash
docker compose exec -T app python -m operatornet.cli create-player --username alice --display-name "Alice"
```

2. Create OS user (inside ssh container) and restart `ssh`:

```bash
docker compose exec -T ssh useradd -m -s /bin/bash alice
docker compose restart ssh
```

If using key auth, set key and restart `ssh`:

```bash
docker compose exec -T app python -m operatornet.cli set-ssh-key --username alice --pubkey-file /path/to/alice.pub
docker compose restart ssh
```

## Migrations fail

```bash
docker compose exec -T app python -m operatornet.cli migrate
docker compose logs -f --tail=200 app
```

## Reset a stuck player

- Disable player:

```bash
docker compose exec -T app python -m operatornet.cli disable-player --username alice
```

- Reset cooldowns:

```bash
docker compose exec -T app python -m operatornet.cli reset-cooldowns --username alice --all
```
