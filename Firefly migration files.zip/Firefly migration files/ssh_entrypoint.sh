#!/usr/bin/env bash
set -euo pipefail

umask 077

: "${OPERATORNET_DB_URL:?Missing OPERATORNET_DB_URL}"
: "${OPERATORNET_REDIS_URL:?Missing OPERATORNET_REDIS_URL}"

: "${OPERATORNET_SSH_PORT_INTERNAL:=2222}"
: "${OPERATORNET_SSH_PASSWORD_AUTH:=1}"
: "${OPERATORNET_SSH_KEY_AUTH:=1}"
: "${OPERATORNET_SSH_USERS:=}"
: "${OPERATORNET_SSH_DEFAULT_PASSWORD:=changeme}"

mkdir -p /etc/ssh /var/run/sshd /etc/operatornet/authorized_keys
# sshd may read `AuthorizedKeysFile` as the target user; allow traversal but prevent directory listing.
chmod 711 /etc/operatornet/authorized_keys

pw_auth="no"
key_auth="no"
if [ "${OPERATORNET_SSH_PASSWORD_AUTH}" = "1" ]; then
  pw_auth="yes"
fi
if [ "${OPERATORNET_SSH_KEY_AUTH}" = "1" ]; then
  key_auth="yes"
fi

# Also provision OS accounts for any existing authorized_keys entries.
for f in /etc/operatornet/authorized_keys/*; do
  [ -f "$f" ] || continue
  u="$(basename "$f")"
  if ! id -u "$u" >/dev/null 2>&1; then
    # Shell is irrelevant due to ForceCommand, but must be executable.
    useradd -m -s /bin/bash "$u"
    # Note: on Debian, "locked" users are refused entirely (even for publickey auth).
    # Instead, set a random password and rely on PasswordAuthentication=no for safety.
    if [ "${OPERATORNET_SSH_PASSWORD_AUTH}" = "1" ]; then
      echo "${u}:${OPERATORNET_SSH_DEFAULT_PASSWORD}" | chpasswd
    else
      echo "${u}:$(head -c 48 /dev/urandom | base64 | tr -d '\n')_opnet" | chpasswd
    fi
    mkdir -p "/home/${u}/.ssh"
    chown -R "${u}:${u}" "/home/${u}/.ssh"
    chmod 700 "/home/${u}/.ssh"
  fi
done

# Optional: provision OS accounts at boot.
# - If key auth is enabled, it is safe to create accounts with locked passwords.
# - If password auth is enabled, a default password can be used (recommended: disable and use keys).
if [ -n "${OPERATORNET_SSH_USERS}" ]; then
  IFS=',' read -r -a USERS <<< "${OPERATORNET_SSH_USERS}"
  for u in "${USERS[@]}"; do
    u="$(echo "$u" | tr -d '[:space:]')"
    [ -z "$u" ] && continue
    if ! id -u "$u" >/dev/null 2>&1; then
      useradd -m -s /bin/bash "$u"
    fi
    if [ "${OPERATORNET_SSH_PASSWORD_AUTH}" = "1" ]; then
      echo "${u}:${OPERATORNET_SSH_DEFAULT_PASSWORD}" | chpasswd
    else
      echo "${u}:$(head -c 48 /dev/urandom | base64 | tr -d '\n')_opnet" | chpasswd
    fi
    mkdir -p "/home/${u}/.ssh"
    chown -R "${u}:${u}" "/home/${u}/.ssh"
    chmod 700 "/home/${u}/.ssh"
  done
fi

# Host keys live on a volume so they persist across restarts.
if [ ! -f /etc/ssh/ssh_host_ed25519_key ]; then
  ssh-keygen -A >/dev/null
fi

cat > /etc/ssh/sshd_config <<EOF
Port ${OPERATORNET_SSH_PORT_INTERNAL}
ListenAddress 0.0.0.0
Protocol 2
HostKey /etc/ssh/ssh_host_ed25519_key
HostKey /etc/ssh/ssh_host_rsa_key

PasswordAuthentication ${pw_auth}
KbdInteractiveAuthentication no
PermitRootLogin no
PubkeyAuthentication ${key_auth}
AuthorizedKeysFile /etc/operatornet/authorized_keys/%u
UsePAM yes

AllowTcpForwarding no
X11Forwarding no
PermitTunnel no
AllowAgentForwarding no

PrintMotd no
Banner none

AcceptEnv LANG LC_*
PermitUserEnvironment no

ClientAliveInterval 60
ClientAliveCountMax 2

# Force all sessions into the game entrypoint (no shell).
ForceCommand /usr/local/bin/operatornet-ssh-entry

# Required env for the forced command (sshd sanitizes env by default).
SetEnv OPERATORNET_DB_URL=${OPERATORNET_DB_URL}
SetEnv OPERATORNET_REDIS_URL=${OPERATORNET_REDIS_URL}
SetEnv OPERATORNET_ENV=${OPERATORNET_ENV:-prod}
SetEnv OPERATORNET_REQUIRE_EXISTING_PLAYER=1
EOF

cat > /usr/local/bin/operatornet-ssh-entry <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

# Use the SSH login as the in-game player identity.
export OPERATORNET_PLAYER="${USER}"
export OPERATORNET_SESSION_SSH=1

cd /app
exec python -m operatornet.cli tui
EOF
chmod 755 /usr/local/bin/operatornet-ssh-entry

exec /usr/sbin/sshd -D -e
