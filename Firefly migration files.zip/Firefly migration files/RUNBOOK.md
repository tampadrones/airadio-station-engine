# OperatorNet Runbook

## Service health

```bash
docker compose ps
docker compose logs -f --tail=200 app
docker compose logs -f --tail=200 ssh
```

## Database migrations

```bash
docker compose exec -T app python -m operatornet.cli migrate
```

## Create / reset admin

```bash
docker compose exec -T app python -m operatornet.cli bootstrap-admin --username admin --password <pw> --display-name "Admin"
```

To make the SSH user see the Admin module, bootstrap that username (default SSH user is `player`):

```bash
docker compose exec -T app python -m operatornet.cli bootstrap-admin --username player --password <pw> --display-name "Player Admin"
```

## Change password

```bash
docker compose exec -T app python -m operatornet.cli set-password --username admin --password <newpw>
```

## Admin tools

```bash
docker compose exec -T app python -m operatornet.cli create-player --username alice --display-name "Alice"
docker compose exec -T app python -m operatornet.cli disable-player --username alice
docker compose exec -T app python -m operatornet.cli give-credits --username alice --amount 500
docker compose exec -T app python -m operatornet.cli give-item --username alice --item SDR_KIT_MK1 --qty 1
docker compose exec -T app python -m operatornet.cli reset-cooldowns --username alice --all
docker compose exec -T app python -m operatornet.cli generate-contracts --count 10
docker compose exec -T app python -m operatornet.cli logs --limit 80 --type trace
```

## Backups

- Quick DB backup:

```bash
bash scripts/backup_db.sh backups/operatornet_$(date +%F).sql
```

- Restore:

```bash
bash scripts/restore_db.sh backups/operatornet_YYYY-MM-DD.sql
```
