#!/usr/bin/env bash
set -euo pipefail

umask 077

: "${OPERATORNET_DB_URL:?Missing OPERATORNET_DB_URL}"
: "${OPERATORNET_REDIS_URL:?Missing OPERATORNET_REDIS_URL}"

# Run migrations + seed once at boot.
python -m operatornet.cli migrate

# Long-running world tick daemon (keeps "game app" container healthy).
exec python -m operatornet.cli daemon

