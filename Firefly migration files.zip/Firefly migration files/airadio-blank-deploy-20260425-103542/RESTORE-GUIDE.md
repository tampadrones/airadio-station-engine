# Airadio Blank Restore Guide

This bundle restores a blank but functional Airadio deployment.

Contents:
- airadio.sql: PostgreSQL schema plus blank data state (application tables truncated; migrations preserved)
- airadio-storage.tar.gz: empty runtime storage volume snapshot
- airadio-project.tar.gz: project files, compose files, app code, infra, and env files from /home/apox/airadio
- SHA256SUMS: checksums for the payload files

Restore steps:
1. Extract the bundle on the target host.
2. Extract airadio-project.tar.gz into /home/apox or another chosen app path.
3. Change into the restored airadio project directory.
4. Start only Postgres first:
   docker compose up -d postgres
5. Wait for Postgres to become healthy, then restore the DB:
   cat ../airadio.sql | docker exec -i airadio-postgres-1 psql -U airadio -d airadio
6. Restore the blank storage snapshot into the Docker volume path for airadio_storage:
   sudo tar xzf ../airadio-storage.tar.gz -C /var/lib/docker/volumes/airadio_airadio_storage/_data
7. Start the full stack:
   docker compose up -d
8. Verify:
   - docker compose ps
   - curl http://127.0.0.1:8000/api/stats/stations
   - open the web UI on port 8088

Notes:
- The restored database intentionally contains no tracks, play history, generated assets, or operational events.
- Default stations are recreated automatically by the API on startup if the stations table is empty.
- If you change ports, hosts, or env values, update .env and compose settings before bringing the full stack up.
