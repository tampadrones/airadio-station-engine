--
-- PostgreSQL database dump
--

\restrict xDg9pKMq5SXteeTnT95nHJQKcj2LBvMfWwcN4EJzk7AGitVmmgfXQlpofxFMaiJ

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: severity; Type: TYPE; Schema: public; Owner: airadio
--

CREATE TYPE public.severity AS ENUM (
    'info',
    'warning',
    'error'
);


ALTER TYPE public.severity OWNER TO airadio;

--
-- Name: storageclass; Type: TYPE; Schema: public; Owner: airadio
--

CREATE TYPE public.storageclass AS ENUM (
    'hot',
    'warm',
    'cold',
    'temp',
    'failed'
);


ALTER TYPE public.storageclass OWNER TO airadio;

--
-- Name: trackstatus; Type: TYPE; Schema: public; Owner: airadio
--

CREATE TYPE public.trackstatus AS ENUM (
    'pending',
    'generating',
    'ready',
    'queued',
    'aired',
    'failed',
    'deleted'
);


ALTER TYPE public.trackstatus OWNER TO airadio;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO airadio;

--
-- Name: audio_assets; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.audio_assets (
    id integer NOT NULL,
    file_path character varying(1024) NOT NULL,
    file_size_bytes bigint,
    audio_format character varying(20),
    sample_rate integer,
    channels integer,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.audio_assets OWNER TO airadio;

--
-- Name: audio_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.audio_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audio_assets_id_seq OWNER TO airadio;

--
-- Name: audio_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.audio_assets_id_seq OWNED BY public.audio_assets.id;


--
-- Name: ops_events; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.ops_events (
    id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    service character varying(80) NOT NULL,
    host character varying(255) NOT NULL,
    station_id integer,
    track_id integer,
    generation_job_id character varying(120),
    severity public.severity NOT NULL,
    event_type character varying(80) NOT NULL,
    message text NOT NULL,
    duration_ms integer,
    error_code character varying(80),
    details json NOT NULL
);


ALTER TABLE public.ops_events OWNER TO airadio;

--
-- Name: ops_events_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.ops_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ops_events_id_seq OWNER TO airadio;

--
-- Name: ops_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.ops_events_id_seq OWNED BY public.ops_events.id;


--
-- Name: station_daily_summary; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.station_daily_summary (
    id integer NOT NULL,
    station_id integer NOT NULL,
    summary_date date NOT NULL,
    tracks_generated integer DEFAULT 0 NOT NULL,
    tracks_aired integer DEFAULT 0 NOT NULL,
    avg_queue_depth double precision,
    min_queue_depth integer,
    avg_generation_latency double precision,
    failures integer DEFAULT 0 NOT NULL,
    avg_qc_score double precision,
    avg_fit_score double precision,
    unique_listeners integer DEFAULT 0 NOT NULL,
    peak_listeners integer DEFAULT 0 NOT NULL,
    reuse_rate double precision,
    storage_used_hot integer DEFAULT 0 NOT NULL,
    storage_used_warm integer DEFAULT 0 NOT NULL,
    deletions integer DEFAULT 0 NOT NULL,
    promotions integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.station_daily_summary OWNER TO airadio;

--
-- Name: station_daily_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.station_daily_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.station_daily_summary_id_seq OWNER TO airadio;

--
-- Name: station_daily_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.station_daily_summary_id_seq OWNED BY public.station_daily_summary.id;


--
-- Name: station_playback_state; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.station_playback_state (
    id integer NOT NULL,
    station_id integer NOT NULL,
    playback_backend character varying(40) DEFAULT 'liquidsoap'::character varying NOT NULL,
    current_track_id integer,
    current_title character varying(200),
    started_at timestamp without time zone,
    position_sec integer,
    fallback_active boolean DEFAULT false NOT NULL,
    manifest_path character varying(1024),
    manifest_age_seconds integer,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.station_playback_state OWNER TO airadio;

--
-- Name: station_playback_state_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.station_playback_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.station_playback_state_id_seq OWNER TO airadio;

--
-- Name: station_playback_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.station_playback_state_id_seq OWNED BY public.station_playback_state.id;


--
-- Name: stations; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.stations (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    name character varying(120) NOT NULL,
    genre character varying(80) NOT NULL,
    personality character varying(120) NOT NULL,
    description text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    circadian_profile json NOT NULL,
    target_queue_depth integer DEFAULT 5 NOT NULL,
    min_ready_tracks integer DEFAULT 3 NOT NULL,
    hot_quota_gb integer DEFAULT 5 NOT NULL,
    warm_quota_gb integer DEFAULT 20 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    station_profile json NOT NULL
);


ALTER TABLE public.stations OWNER TO airadio;

--
-- Name: stations_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.stations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stations_id_seq OWNER TO airadio;

--
-- Name: stations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.stations_id_seq OWNED BY public.stations.id;


--
-- Name: track_analysis; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.track_analysis (
    track_id integer NOT NULL,
    bpm double precision,
    key_signature character varying(16),
    energy_score double precision,
    brightness_score double precision,
    density_score double precision,
    vocal_presence_score double precision,
    station_fit_score double precision,
    qc_score double precision,
    replay_score double precision,
    similarity_fingerprint character varying(256),
    embedding_ref character varying(256),
    tags json NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.track_analysis OWNER TO airadio;

--
-- Name: track_feedback; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.track_feedback (
    id integer NOT NULL,
    station_id integer NOT NULL,
    track_id integer NOT NULL,
    session_id character varying(128) NOT NULL,
    vote integer NOT NULL,
    source character varying(40) DEFAULT 'web'::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT ck_track_feedback_vote CHECK ((vote = ANY (ARRAY['-1'::integer, 1])))
);


ALTER TABLE public.track_feedback OWNER TO airadio;

--
-- Name: track_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.track_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.track_feedback_id_seq OWNER TO airadio;

--
-- Name: track_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.track_feedback_id_seq OWNED BY public.track_feedback.id;


--
-- Name: track_generation; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.track_generation (
    track_id integer NOT NULL,
    prompt_text text NOT NULL,
    negative_prompt_text text,
    generator_model character varying(120),
    generator_host character varying(255) NOT NULL,
    generation_seconds double precision,
    seed integer,
    genre character varying(80) NOT NULL,
    personality character varying(120) NOT NULL,
    mood_state character varying(40) NOT NULL,
    daypart character varying(40) NOT NULL,
    recent_context json NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.track_generation OWNER TO airadio;

--
-- Name: track_play_events; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.track_play_events (
    id integer NOT NULL,
    track_id integer NOT NULL,
    station_id integer NOT NULL,
    played_at timestamp without time zone NOT NULL,
    listeners_at_start integer,
    listeners_peak integer,
    completed boolean DEFAULT false NOT NULL,
    skip_rate double precision,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.track_play_events OWNER TO airadio;

--
-- Name: track_play_events_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.track_play_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.track_play_events_id_seq OWNER TO airadio;

--
-- Name: track_play_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.track_play_events_id_seq OWNED BY public.track_play_events.id;


--
-- Name: track_promotion; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.track_promotion (
    track_id integer NOT NULL,
    promoted_to_library boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    signature_track boolean DEFAULT false NOT NULL,
    reason text,
    promoted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.track_promotion OWNER TO airadio;

--
-- Name: tracks; Type: TABLE; Schema: public; Owner: airadio
--

CREATE TABLE public.tracks (
    id integer NOT NULL,
    station_id integer NOT NULL,
    title character varying(200) NOT NULL,
    status public.trackstatus NOT NULL,
    storage_class public.storageclass NOT NULL,
    duration_sec integer,
    audio_format character varying(20),
    bitrate_kbps integer,
    sample_rate integer,
    channels integer,
    file_path character varying(1024),
    preview_path character varying(1024),
    file_size_bytes bigint,
    created_at timestamp without time zone NOT NULL,
    aired_at timestamp without time zone,
    expires_at timestamp without time zone,
    deleted_at timestamp without time zone,
    audio_asset_id integer
);


ALTER TABLE public.tracks OWNER TO airadio;

--
-- Name: tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: airadio
--

CREATE SEQUENCE public.tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tracks_id_seq OWNER TO airadio;

--
-- Name: tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: airadio
--

ALTER SEQUENCE public.tracks_id_seq OWNED BY public.tracks.id;


--
-- Name: audio_assets id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.audio_assets ALTER COLUMN id SET DEFAULT nextval('public.audio_assets_id_seq'::regclass);


--
-- Name: ops_events id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.ops_events ALTER COLUMN id SET DEFAULT nextval('public.ops_events_id_seq'::regclass);


--
-- Name: station_daily_summary id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.station_daily_summary ALTER COLUMN id SET DEFAULT nextval('public.station_daily_summary_id_seq'::regclass);


--
-- Name: station_playback_state id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.station_playback_state ALTER COLUMN id SET DEFAULT nextval('public.station_playback_state_id_seq'::regclass);


--
-- Name: stations id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.stations ALTER COLUMN id SET DEFAULT nextval('public.stations_id_seq'::regclass);


--
-- Name: track_feedback id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_feedback ALTER COLUMN id SET DEFAULT nextval('public.track_feedback_id_seq'::regclass);


--
-- Name: track_play_events id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_play_events ALTER COLUMN id SET DEFAULT nextval('public.track_play_events_id_seq'::regclass);


--
-- Name: tracks id; Type: DEFAULT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.tracks ALTER COLUMN id SET DEFAULT nextval('public.tracks_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.alembic_version (version_num) FROM stdin;
0005_track_feedback
\.


--
-- Data for Name: audio_assets; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.audio_assets (id, file_path, file_size_bytes, audio_format, sample_rate, channels, created_at) FROM stdin;
\.


--
-- Data for Name: ops_events; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.ops_events (id, "timestamp", service, host, station_id, track_id, generation_job_id, severity, event_type, message, duration_ms, error_code, details) FROM stdin;
\.


--
-- Data for Name: station_daily_summary; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.station_daily_summary (id, station_id, summary_date, tracks_generated, tracks_aired, avg_queue_depth, min_queue_depth, avg_generation_latency, failures, avg_qc_score, avg_fit_score, unique_listeners, peak_listeners, reuse_rate, storage_used_hot, storage_used_warm, deletions, promotions, created_at) FROM stdin;
\.


--
-- Data for Name: station_playback_state; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.station_playback_state (id, station_id, playback_backend, current_track_id, current_title, started_at, position_sec, fallback_active, manifest_path, manifest_age_seconds, updated_at) FROM stdin;
\.


--
-- Data for Name: stations; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.stations (id, slug, name, genre, personality, description, is_enabled, circadian_profile, target_queue_depth, min_ready_tracks, hot_quota_gb, warm_quota_gb, created_at, updated_at, station_profile) FROM stdin;
\.


--
-- Data for Name: track_analysis; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.track_analysis (track_id, bpm, key_signature, energy_score, brightness_score, density_score, vocal_presence_score, station_fit_score, qc_score, replay_score, similarity_fingerprint, embedding_ref, tags, created_at) FROM stdin;
\.


--
-- Data for Name: track_feedback; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.track_feedback (id, station_id, track_id, session_id, vote, source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: track_generation; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.track_generation (track_id, prompt_text, negative_prompt_text, generator_model, generator_host, generation_seconds, seed, genre, personality, mood_state, daypart, recent_context, created_at) FROM stdin;
\.


--
-- Data for Name: track_play_events; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.track_play_events (id, track_id, station_id, played_at, listeners_at_start, listeners_peak, completed, skip_rate, created_at) FROM stdin;
\.


--
-- Data for Name: track_promotion; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.track_promotion (track_id, promoted_to_library, pinned, signature_track, reason, promoted_at, created_at) FROM stdin;
\.


--
-- Data for Name: tracks; Type: TABLE DATA; Schema: public; Owner: airadio
--

COPY public.tracks (id, station_id, title, status, storage_class, duration_sec, audio_format, bitrate_kbps, sample_rate, channels, file_path, preview_path, file_size_bytes, created_at, aired_at, expires_at, deleted_at, audio_asset_id) FROM stdin;
\.


--
-- Name: audio_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.audio_assets_id_seq', 1, false);


--
-- Name: ops_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.ops_events_id_seq', 1, false);


--
-- Name: station_daily_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.station_daily_summary_id_seq', 1, false);


--
-- Name: station_playback_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.station_playback_state_id_seq', 1, false);


--
-- Name: stations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.stations_id_seq', 1, false);


--
-- Name: track_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.track_feedback_id_seq', 1, false);


--
-- Name: track_play_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.track_play_events_id_seq', 1, false);


--
-- Name: tracks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: airadio
--

SELECT pg_catalog.setval('public.tracks_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audio_assets audio_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.audio_assets
    ADD CONSTRAINT audio_assets_pkey PRIMARY KEY (id);


--
-- Name: ops_events ops_events_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.ops_events
    ADD CONSTRAINT ops_events_pkey PRIMARY KEY (id);


--
-- Name: station_daily_summary station_daily_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.station_daily_summary
    ADD CONSTRAINT station_daily_summary_pkey PRIMARY KEY (id);


--
-- Name: station_playback_state station_playback_state_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.station_playback_state
    ADD CONSTRAINT station_playback_state_pkey PRIMARY KEY (id);


--
-- Name: stations stations_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.stations
    ADD CONSTRAINT stations_pkey PRIMARY KEY (id);


--
-- Name: track_analysis track_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_analysis
    ADD CONSTRAINT track_analysis_pkey PRIMARY KEY (track_id);


--
-- Name: track_feedback track_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_feedback
    ADD CONSTRAINT track_feedback_pkey PRIMARY KEY (id);


--
-- Name: track_generation track_generation_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_generation
    ADD CONSTRAINT track_generation_pkey PRIMARY KEY (track_id);


--
-- Name: track_play_events track_play_events_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_play_events
    ADD CONSTRAINT track_play_events_pkey PRIMARY KEY (id);


--
-- Name: track_promotion track_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_promotion
    ADD CONSTRAINT track_promotion_pkey PRIMARY KEY (track_id);


--
-- Name: tracks tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_pkey PRIMARY KEY (id);


--
-- Name: track_feedback uq_track_feedback_station_track_session; Type: CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_feedback
    ADD CONSTRAINT uq_track_feedback_station_track_session UNIQUE (station_id, track_id, session_id);


--
-- Name: ix_audio_assets_file_path; Type: INDEX; Schema: public; Owner: airadio
--

CREATE UNIQUE INDEX ix_audio_assets_file_path ON public.audio_assets USING btree (file_path);


--
-- Name: ix_ops_events_event_type; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_ops_events_event_type ON public.ops_events USING btree (event_type);


--
-- Name: ix_ops_events_generation_job_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_ops_events_generation_job_id ON public.ops_events USING btree (generation_job_id);


--
-- Name: ix_ops_events_severity; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_ops_events_severity ON public.ops_events USING btree (severity);


--
-- Name: ix_ops_events_station_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_ops_events_station_id ON public.ops_events USING btree (station_id);


--
-- Name: ix_ops_events_timestamp; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_ops_events_timestamp ON public.ops_events USING btree ("timestamp");


--
-- Name: ix_ops_events_track_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_ops_events_track_id ON public.ops_events USING btree (track_id);


--
-- Name: ix_station_daily_summary_station_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_station_daily_summary_station_id ON public.station_daily_summary USING btree (station_id);


--
-- Name: ix_station_daily_summary_summary_date; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_station_daily_summary_summary_date ON public.station_daily_summary USING btree (summary_date);


--
-- Name: ix_station_playback_state_current_track_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_station_playback_state_current_track_id ON public.station_playback_state USING btree (current_track_id);


--
-- Name: ix_station_playback_state_station_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE UNIQUE INDEX ix_station_playback_state_station_id ON public.station_playback_state USING btree (station_id);


--
-- Name: ix_stations_slug; Type: INDEX; Schema: public; Owner: airadio
--

CREATE UNIQUE INDEX ix_stations_slug ON public.stations USING btree (slug);


--
-- Name: ix_track_feedback_session_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_track_feedback_session_id ON public.track_feedback USING btree (session_id);


--
-- Name: ix_track_feedback_station_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_track_feedback_station_id ON public.track_feedback USING btree (station_id);


--
-- Name: ix_track_feedback_track_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_track_feedback_track_id ON public.track_feedback USING btree (track_id);


--
-- Name: ix_track_play_events_station_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_track_play_events_station_id ON public.track_play_events USING btree (station_id);


--
-- Name: ix_track_play_events_track_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_track_play_events_track_id ON public.track_play_events USING btree (track_id);


--
-- Name: ix_tracks_audio_asset_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_tracks_audio_asset_id ON public.tracks USING btree (audio_asset_id);


--
-- Name: ix_tracks_station_id; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_tracks_station_id ON public.tracks USING btree (station_id);


--
-- Name: ix_tracks_status; Type: INDEX; Schema: public; Owner: airadio
--

CREATE INDEX ix_tracks_status ON public.tracks USING btree (status);


--
-- Name: tracks fk_tracks_audio_asset_id; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT fk_tracks_audio_asset_id FOREIGN KEY (audio_asset_id) REFERENCES public.audio_assets(id);


--
-- Name: ops_events ops_events_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.ops_events
    ADD CONSTRAINT ops_events_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.stations(id);


--
-- Name: ops_events ops_events_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.ops_events
    ADD CONSTRAINT ops_events_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: station_daily_summary station_daily_summary_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.station_daily_summary
    ADD CONSTRAINT station_daily_summary_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.stations(id);


--
-- Name: station_playback_state station_playback_state_current_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.station_playback_state
    ADD CONSTRAINT station_playback_state_current_track_id_fkey FOREIGN KEY (current_track_id) REFERENCES public.tracks(id);


--
-- Name: station_playback_state station_playback_state_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.station_playback_state
    ADD CONSTRAINT station_playback_state_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.stations(id);


--
-- Name: track_analysis track_analysis_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_analysis
    ADD CONSTRAINT track_analysis_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: track_feedback track_feedback_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_feedback
    ADD CONSTRAINT track_feedback_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.stations(id);


--
-- Name: track_feedback track_feedback_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_feedback
    ADD CONSTRAINT track_feedback_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: track_generation track_generation_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_generation
    ADD CONSTRAINT track_generation_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: track_play_events track_play_events_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_play_events
    ADD CONSTRAINT track_play_events_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.stations(id);


--
-- Name: track_play_events track_play_events_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_play_events
    ADD CONSTRAINT track_play_events_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: track_promotion track_promotion_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.track_promotion
    ADD CONSTRAINT track_promotion_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: tracks tracks_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: airadio
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.stations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict xDg9pKMq5SXteeTnT95nHJQKcj2LBvMfWwcN4EJzk7AGitVmmgfXQlpofxFMaiJ

