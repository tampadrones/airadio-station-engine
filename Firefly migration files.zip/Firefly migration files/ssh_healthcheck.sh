#!/usr/bin/env bash
set -euo pipefail

pgrep -x sshd >/dev/null
python -m operatornet.cli healthcheck

