# Install / Deploy

## Requirements

- Docker + Docker Compose on the target host

## Deploy on TrueNAS (10.0.0.5)

1. Copy this repo directory to the server (for example `~/operatornet`).
2. Create `.env` from `.env.example` and set:
   - `POSTGRES_PASSWORD` (required)
   - `OPERATORNET_SSH_PORT` (optional, default `2222`)
   - `OPERATORNET_SSH_PASSWORD_AUTH` / `OPERATORNET_SSH_KEY_AUTH`
3. Start:

```bash
docker compose up -d --build
docker compose exec -T app python -m operatornet.cli bootstrap-admin --username admin --password <pw> --display-name "Admin"
```

4. Create a player (DB) and enable SSH access:

```bash
docker compose exec -T app python -m operatornet.cli create-player --username alice --display-name "Alice"
```

Key auth (recommended): set the user's public key, then restart `ssh` so the container provisions the OS account.

```bash
docker compose exec -T app python -m operatornet.cli set-ssh-key --username alice --pubkey-file /path/to/alice.pub
docker compose restart ssh
```

Password auth (optional): set `OPERATORNET_SSH_PASSWORD_AUTH=1`, then either pre-provision via env (`OPERATORNET_SSH_USERS=alice,bob` + `OPERATORNET_SSH_DEFAULT_PASSWORD=<pw>`) or create the OS user inside the container and set a password. Key auth is recommended for production.

5. SSH test:

```bash
ssh -p ${OPERATORNET_SSH_PORT:-2222} <username>@10.0.0.5
```
