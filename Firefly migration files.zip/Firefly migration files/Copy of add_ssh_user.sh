#!/usr/bin/env bash
set -euo pipefail

# Create (or unlock) an OS-level SSH account inside the `ssh` container.
# Usage: bash scripts/add_ssh_user.sh <username>
#
# Note: For key-based auth, the recommended flow is:
# - `docker compose exec -T app python -m operatornet.cli set-ssh-key ...`
# - `docker compose restart ssh`
# The `ssh` container will then auto-provision the OS user on boot.

U="${1:-}"
if [ -z "$U" ]; then
  echo "usage: $0 <username>" >&2
  exit 2
fi

docker compose exec -T ssh bash -lc "id -u \"$U\" >/dev/null 2>&1 || useradd -m -s /bin/bash \"$U\"; echo \"$U:$(head -c 48 /dev/urandom | base64 | tr -d '\n')_opnet\" | chpasswd" >/dev/null
docker compose restart ssh >/dev/null
echo "ssh user ensured: $U"
