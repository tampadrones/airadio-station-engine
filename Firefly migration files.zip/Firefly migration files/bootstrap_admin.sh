#!/usr/bin/env bash
set -euo pipefail

# Bootstrap an OperatorNet admin user inside the running Compose stack.
#
# Usage:
#   ./scripts/bootstrap_admin.sh [username] [display_name]
#
# The generated credentials are written to:
#   ./admin_credentials.txt
#
# You can override the password by setting:
#   OPERATORNET_ADMIN_PASSWORD=...

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

username="${1:-admin}"
display_name="${2:-Admin}"

pw="${OPERATORNET_ADMIN_PASSWORD:-}"
if [ -z "$pw" ]; then
  if command -v openssl >/dev/null 2>&1; then
    pw="$(openssl rand -hex 12)"
  else
    pw="$(python3 -c 'import secrets;print(secrets.token_hex(12))')"
  fi
fi

docker compose exec -T app python -m operatornet.cli bootstrap-admin --username "$username" --password "$pw" --display-name "$display_name"

umask 077
printf "%s:%s\n" "$username" "$pw" > "$ROOT_DIR/admin_credentials.txt"
chmod 600 "$ROOT_DIR/admin_credentials.txt"

echo "ok: wrote admin credentials to $ROOT_DIR/admin_credentials.txt"

