# OperatorNet: Signal Wars

SSH-accessible terminal game powered by Python + Textual.

## Quick start (Docker)

```bash
cd operatornet
cp .env.example .env
docker compose up -d --build
docker compose exec -T app python -m operatornet.cli bootstrap-admin --username admin --password admin --display-name "Admin"
```

## SSH into the game

The SSH entrypoint listens on TCP port `2222` (configurable via `OPERATORNET_SSH_PORT`):

```bash
ssh -p 2222 <username>@<server-ip>
```

All SSH sessions are forced directly into the Textual TUI (no shell).

## Create a player (DB) + SSH account

Create the in-game player:

```bash
docker compose exec -T app python -m operatornet.cli create-player --username alice --display-name "Alice" --password "<temp_pw>"
```

Create the SSH OS account (or set `OPERATORNET_SSH_USERS=alice` and restart `ssh`):

```bash
docker compose exec -T ssh useradd -m -s /bin/bash alice
docker compose restart ssh
```

Optional key-based auth (recommended): set a public key file and restart `ssh`:

```bash
docker compose exec -T app python -m operatornet.cli set-ssh-key --username alice --pubkey-file /path/to/alice.pub
docker compose restart ssh
```

## OperatorOS UI (keyboard)

- `↑/↓` or `j/k`: navigate left pane
- `Enter`: open module
- `Esc`: back / return focus
- `:`: focus command bar

Try `help`, `go contracts`, `status`.

Contracts loop:

- `contract list`
- `contract accept <#>`
- `contract resolve`
- `contract hide` (defensive trace reduction)

Tactical commands (fictional, safe):

- `scan + fingerprint`
- `scan -> fingerprint -> spoof`
- `jam adaptive`
- `upload firmware`
- `decode telemetry`

If you have an active contract, running a tactical chain will resolve it (SUCCESS/PARTIAL/FAILURE) and persist rewards/cooldowns/trace.

Immersive mini-games (simulated operator terminals):

- Accept a contract, then run `sim start`
- While a mini-game is active, type its mode commands directly (Tab shows suggestions)
- Example (SDR scan): `activate sdr0` → `scan --band 900-930MHz` → `analyze <signal_id>` → `export intel`

## Local dev

```bash
cd operatornet
make venv
make install
cp .env.example .env
make run
```

## Commands

- `python -m operatornet.cli migrate` – apply migrations
- `python -m operatornet.cli bootstrap-admin ...` – create the first admin player
- `python -m operatornet.cli set-password ...` – change an existing player password
- `python -m operatornet.cli create-player ...` – create player + starter kit
- `python -m operatornet.cli disable-player ...` – disable player
- `python -m operatornet.cli give-credits ...` / `give-item ...` – admin grants
- `python -m operatornet.cli backup-db --out ...` / `restore-db --in ...` – backups

## Ops docs

- `INSTALL.md`
- `RUNBOOK.md`
- `SECURITY.md`
- `BACKUP.md`
- `TROUBLESHOOTING.md`
