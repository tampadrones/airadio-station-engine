import { supabase, supabaseConfigError } from "./lib/supabaseClient";
import { ensurePilotProfile, generateUniqueSlug, slugifyPilotName, validateSlug } from "./lib/profile";
import { createProduct, deleteProduct, getOrders, getProducts, updateProduct, uploadProductImage } from "./lib/products";
import { getPrintifyDefaultsForType } from "./lib/productDefaults";
import { getPilotEarnings } from "./lib/earnings";
import {
  getAllPayouts,
  getPilotEmails,
  getPilotPayouts,
  processAdminPayout,
  requestPilotPayout,
  validateCashAppTag,
} from "./lib/payouts";
import { getPilotFulfillmentJobs, submitFulfillmentOrder } from "./lib/fulfillment";
import { getFeaturedPilots, searchPilots } from "./lib/pilots";
import { createCheckoutSession, fetchOrderSuccess, getActiveProductsByUserId, getPilotBySlug, getVideosByUserId } from "./lib/storefront";
import { deleteSocialAccount, getSocialAccounts, upsertSocialAccount } from "./lib/socials";
import { getChannelVideos } from "./lib/youtube";
import { createVideo, deleteVideo, extractYouTubeId, getVideos, updateVideo } from "./lib/videos";
import {
  MAX_MESSAGE_LENGTH,
  createOrGetThread,
  getMessages,
  getThreads,
  getUnreadMessageCount,
  markThreadRead,
  sendMessage,
  triggerMessageEmailNotification,
} from "./lib/messages";
import SetupScreen from "./components/SetupScreen";
import AuthTest from "./AuthTest";
import React, { useEffect, useMemo, useState } from "react";
import { BrowserRouter, Link, Navigate, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  Bell,
  MessageSquare,
  Search,
  User,
  BarChart3,
  Store,
  Video,
  Settings,
  Plus,
  Share2,
  ExternalLink,
  Globe,
  Package,
  Users,
  Eye,
  DollarSign,
  ShoppingBag,
  Send,
  Shield,
  PlayCircle,
  Camera,
  Music2,
  LogOut,
  ToggleRight,
  ToggleLeft,
  CheckCircle2,
  AlertCircle,
  MapPin,
} from "lucide-react";
import { motion } from "framer-motion";
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const navItems = [
  { id: "overview", label: "Overview", icon: BarChart3 },
  { id: "store", label: "Store", icon: Store },
  { id: "content", label: "Content", icon: Video },
  { id: "messages", label: "Messages", icon: MessageSquare },
  { id: "settings", label: "Settings", icon: Settings },
];

function getLast7DayRevenueData(orders) {
  const dayKeys = [];
  const byDay = new Map();
  const now = new Date();
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    dayKeys.push(key);
    byDay.set(key, 0);
  }

  for (const row of orders || []) {
    const status = String(row?.status || "").toLowerCase();
    if (status !== "paid") continue;
    const createdAt = row?.created_at ? new Date(row.created_at) : null;
    if (!createdAt || Number.isNaN(createdAt.getTime())) continue;
    const key = createdAt.toISOString().slice(0, 10);
    if (!byDay.has(key)) continue;
    byDay.set(key, byDay.get(key) + Number(row.amount || 0));
  }

  return dayKeys.map((key) => {
    const date = new Date(`${key}T00:00:00`);
    const day = date.toLocaleDateString([], { weekday: "short" });
    return { day, revenue: Number(byDay.get(key) || 0) };
  });
}

const productTypes = ["T-Shirt", "Hoodie", "Stickers"];
const fulfillmentProviderOptions = [
  { key: "mock", label: "Mock" },
  { key: "printify", label: "Printify" },
];

function normalizeProductType(value) {
  const raw = String(value || "").trim().toLowerCase();
  if (raw === "t-shirt" || raw === "t_shirt" || raw === "tshirt") return "t_shirt";
  if (raw === "hoodie") return "hoodie";
  if (raw === "stickers" || raw === "sticker") return "sticker";
  return "other";
}

function getPrintifyReadiness(product) {
  const normalizedType = normalizeProductType(product?.product_type);
  const typeSupported = ["t_shirt", "hoodie", "sticker"].includes(normalizedType);
  const defaults = getPrintifyDefaultsForType(product?.product_type);
  const hasVariant = Boolean(product?.printify_variant_id || defaults.variantId);
  const hasDesign = Boolean(String(product?.design_image_url || "").trim());
  const hasBlueprintProvider = Boolean(
    (product?.printify_blueprint_id || defaults.blueprintId) &&
    (product?.printify_print_provider_id || defaults.printProviderId)
  );
  const hasPrice = Number(product?.price || 0) > 0;
  const defaultsConfigured = Boolean(defaults.isConfigured);
  const ready = typeSupported && hasVariant && hasDesign && hasBlueprintProvider && hasPrice && defaultsConfigured;
  return { ready, typeSupported, hasVariant, hasDesign, hasBlueprintProvider, hasPrice, defaultsConfigured };
}

function money(value) {
  return `$${Number(value || 0).toFixed(2)}`;
}

function shortId(value) {
  const raw = String(value || "");
  if (!raw) return "-";
  if (raw.length <= 12) return raw;
  return `${raw.slice(0, 8)}...${raw.slice(-4)}`;
}

function formatShippingAddress(order) {
  const parts = [
    order?.shipping_address_line1,
    order?.shipping_address_line2,
    [order?.shipping_city, order?.shipping_state].filter(Boolean).join(", "),
    order?.shipping_postal_code,
    order?.shipping_country,
  ]
    .map((part) => String(part || "").trim())
    .filter(Boolean);
  return parts.join(", ");
}

function getOrderSubtotal(order) {
  const firstItem = Array.isArray(order?.order_items) ? order.order_items[0] : null;
  return Number(order?.subtotal ?? firstItem?.line_total ?? order?.amount ?? 0);
}

function getOrderShipping(order) {
  return Number(order?.shipping_amount ?? 0);
}

function getOrderTotal(order) {
  return Number(order?.total ?? order?.amount ?? 0);
}

function formatMessageTime(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatUnreadBadgeCount(value) {
  if (!value || value <= 0) return "";
  return value > 99 ? "99+" : String(value);
}

const SOCIAL_PLATFORM_CONFIG = [
  { key: "youtube", label: "YouTube" },
  { key: "instagram", label: "Instagram" },
  { key: "tiktok", label: "TikTok" },
  { key: "x", label: "X / Twitter" },
  { key: "facebook", label: "Facebook" },
  { key: "multigp", label: "MultiGP" },
  { key: "website", label: "Website" },
];

function getPilotPublicSocials(pilot) {
  const accounts = Array.isArray(pilot?.social_accounts) ? pilot.social_accounts : [];
  if (accounts.length > 0) return accounts;

  const fallback = [];
  if (pilot?.youtube_url) fallback.push({ platform: "youtube", profile_url: pilot.youtube_url });
  if (pilot?.instagram_url) fallback.push({ platform: "instagram", profile_url: pilot.instagram_url });
  if (pilot?.tiktok_url) fallback.push({ platform: "tiktok", profile_url: pilot.tiktok_url });
  return fallback;
}

function socialLabel(platform) {
  return SOCIAL_PLATFORM_CONFIG.find((row) => row.key === platform)?.label || platform;
}

function parseAdminEmails(user) {
  const adminEmails = String(import.meta.env.VITE_ADMIN_EMAILS || "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);

  return Boolean(user?.email && adminEmails.includes(user.email.toLowerCase()));
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/pilots" element={<PilotDirectoryPage />} />
        <Route path="/p/:slug" element={<PublicStorefrontPage />} />
        <Route path="/order/success/:orderId" element={<OrderSuccessPage />} />
        <Route path="/admin/payouts" element={<div>Admin Disabled</div>} />
        <Route path="/dashboard/messages" element={<DashboardApp />} />
        <Route path="/dashboard/*" element={<DashboardApp />} />
        <Route path="/login" element={<DashboardApp />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

function useAuthSession() {
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    if (!supabase) {
      setAuthLoading(false);
      return;
    }

    let cancelled = false;

    async function init() {
      const { data } = await supabase.auth.getSession();
      if (!cancelled) {
        setSession(data?.session || null);
        setAuthLoading(false);
      }
    }

    init();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!cancelled) {
        setSession(nextSession || null);
        setAuthLoading(false);
      }
    });

    return () => {
      cancelled = true;
      listener.subscription.unsubscribe();
    };
  }, []);

  return { session, authLoading };
}

function PublicNav() {
  const { session } = useAuthSession();

  return (
    <header className="border-b border-slate-800 bg-[#0B0F14]/95 px-4 py-4 backdrop-blur md:px-6">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
        <Link to="/" className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-emerald-500 font-black text-black">Q</div>
          <div>
            <div className="text-lg font-black tracking-tight">QuadRoster</div>
            <div className="text-[11px] uppercase tracking-[0.2em] text-orange-400">Pilot Network</div>
          </div>
        </Link>
        <nav className="flex flex-wrap items-center gap-2 text-sm font-semibold">
          <Link to="/pilots" className="rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 hover:border-emerald-500">
            Browse Pilots
          </Link>
          <Link to="/dashboard" className="rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 hover:border-emerald-500">
            Dashboard
          </Link>
          <Link to={session ? "/dashboard" : "/login"} className="rounded-2xl bg-orange-500 px-4 py-2 font-black text-black hover:bg-orange-400">
            {session ? "Account" : "Sign In"}
          </Link>
        </nav>
      </div>
    </header>
  );
}

function PilotCard({ pilot }) {
  const socials = getPilotPublicSocials(pilot);
  const followerCount = Number(pilot?.follower_count || 0);
  const salesCount = Number(pilot?.total_sales || 0);
  const topVideoThumb = pilot?.top_video?.youtube_video_id
    ? `https://i.ytimg.com/vi/${pilot.top_video.youtube_video_id}/hqdefault.jpg`
    : "";
  return (
    <Link to={`/p/${pilot.slug}`} className="group block rounded-3xl border border-slate-800 bg-[#111827] p-4 transition hover:border-emerald-500 hover:shadow-[0_0_30px_rgba(16,185,129,0.12)]">
      <div className="flex items-start gap-3">
        <div className="flex h-14 w-14 flex-none items-center justify-center overflow-hidden rounded-2xl border border-slate-700 bg-slate-950 text-xl font-black text-emerald-400">
          {pilot.avatar_url ? (
            <img src={pilot.avatar_url} alt={pilot.pilot_name} className="h-full w-full object-cover" />
          ) : (
            (pilot.pilot_name || "P").charAt(0).toUpperCase()
          )}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-lg font-black group-hover:text-emerald-400">{pilot.pilot_name || "Unnamed Pilot"}</h3>
          <div className="mt-1 flex items-center gap-1 text-sm text-slate-400">
            <MapPin className="h-4 w-4" />
            <span className="truncate">{pilot.location || "Location not set"}</span>
          </div>
          <div className="mt-1 truncate text-xs text-slate-500">/{pilot.slug}</div>
        </div>
      </div>
      <p className="mt-4 line-clamp-3 text-sm text-slate-300">{pilot.bio || "No bio added yet."}</p>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
        <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-2">
          <div className="text-slate-500">Followers</div>
          <div className="font-black">{followerCount.toLocaleString()}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-2">
          <div className="text-slate-500">Sales</div>
          <div className="font-black">{salesCount.toLocaleString()}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-2">
          <div className="text-slate-500">Rating</div>
          <div className="font-black">4.9</div>
        </div>
      </div>
      <div className="mt-3 overflow-hidden rounded-2xl border border-slate-800 bg-slate-950">
        {topVideoThumb ? (
          <img src={topVideoThumb} alt="Top video" className="h-28 w-full object-cover" />
        ) : (
          <div className="flex h-28 items-center justify-center text-xs text-slate-500">No featured video yet</div>
        )}
      </div>
      <div className="mt-4 flex items-center gap-2 text-slate-400">
        {socials.slice(0, 5).map((social) => (
          <span key={`${pilot.user_id}-${social.platform}`} title={socialLabel(social.platform)}>
            <Globe className="h-4 w-4" />
          </span>
        ))}
      </div>
      <div className="mt-4 inline-flex rounded-xl border border-slate-700 px-3 py-2 text-xs font-bold group-hover:border-emerald-500">
        View Pilot
      </div>
    </Link>
  );
}

function LandingPage() {
  const [session, setSession] = useState(null);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data?.session || null));
  }, []);

  const [featuredPilots, setFeaturedPilots] = useState([]);
  const [authLoading, setAuthLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    async function loadFeatured() {
      setAuthLoading(true);
      setError("");
      try {
        const pilots = await getFeaturedPilots(6);
        if (!cancelled) setFeaturedPilots(pilots);
      } catch (err) {
        if (!cancelled) setError(err?.message || "Unable to load featured pilots.");
      } finally {
        if (!cancelled) setAuthLoading(false);
      }
    }
    loadFeatured();
    return () => {
      cancelled = true;
    };
  }, []);



  const featureCards = [
    { title: "Pilot Profiles", copy: "Find pilots by name, location, and unique callsign slug." },
    { title: "YouTube Showcase", copy: "Watch featured flights and latest uploads directly on each profile." },
    { title: "Merch Storefronts", copy: "Support pilots with merch collections connected to their public page." },
    { title: "Direct Messages", copy: "Start a private thread with pilots to ask questions or collaborate." },
  ];

  return (
    <div className="min-h-screen bg-[#0B0F14] text-slate-100">
      <PublicNav />
      <main className="mx-auto max-w-7xl px-4 py-8 md:px-8 md:py-12">
        <section className="rounded-3xl border border-slate-800 bg-gradient-to-br from-emerald-900/20 via-[#111827] to-orange-900/20 p-8 md:p-12">
          <h1 className="text-4xl font-black tracking-tight md:text-5xl">The FPV Pilot Network</h1>
          <p className="mt-4 max-w-3xl text-base text-slate-300 md:text-lg">
            Discover pilots, watch their flying, message them, and support their merch.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/pilots" className="rounded-2xl bg-emerald-500 px-5 py-3 text-sm font-black text-black hover:bg-emerald-400">
              Browse Pilots
            </Link>
            <Link to="/dashboard" className="rounded-2xl border border-slate-700 bg-slate-900 px-5 py-3 text-sm font-bold hover:border-orange-500">
              Create Pilot Profile
            </Link>
          </div>
        </section>

        <section className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {featureCards.map((feature) => (
            <div key={feature.title} className="rounded-3xl border border-slate-800 bg-[#111827] p-5">
              <h2 className="text-lg font-black">{feature.title}</h2>
              <p className="mt-2 text-sm text-slate-300">{feature.copy}</p>
            </div>
          ))}
        </section>

        <section className="mt-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black">Featured Pilots</h2>
            <Link to="/pilots" className="text-sm font-bold text-emerald-400 hover:text-emerald-300">
              View all
            </Link>
          </div>
          {authLoading && (
            <div className="mt-4 rounded-2xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">Loading pilots...</div>
          )}
          {!authLoading && error && (
            <div className="mt-4 rounded-2xl border border-orange-500/30 bg-orange-500/10 p-4 text-sm text-orange-300">{error}</div>
          )}
          {!authLoading && !error && featuredPilots.length === 0 && (
            <div className="mt-4 rounded-2xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">No pilots found yet.</div>
          )}
          {!authLoading && !error && featuredPilots.length > 0 && (
            <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {featuredPilots.map((pilot) => (
                <PilotCard key={pilot.id} pilot={pilot} />
              ))}
            </div>
          )}
        </section>
      </main>
      <footer className="border-t border-slate-800 bg-[#0B0F14]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-6 text-sm text-slate-400 md:px-8">
          <div className="font-semibold text-slate-300">QuadRoster</div>
          <div className="flex items-center gap-4">
            <Link to="/" className="hover:text-slate-200">Home</Link>
            <Link to="/pilots" className="hover:text-slate-200">Pilots</Link>
            <Link to="/dashboard" className="hover:text-slate-200">Dashboard</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

function PilotDirectoryPage() {
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState("trending");
  const [authLoading, setAuthLoading] = useState(true);
  const [error, setError] = useState("");
  const [pilots, setPilots] = useState([]);
  const [featuredPilots, setFeaturedPilots] = useState([]);

  useEffect(() => {
    let cancelled = false;
    async function loadPilots() {
      setAuthLoading(true);
      setError("");
      try {
        const [rows, featured] = await Promise.all([
          query.trim() ? searchPilots(query.trim()) : searchPilots(""),
          getFeaturedPilots(6),
        ]);
        if (!cancelled) {
          setPilots(rows);
          setFeaturedPilots(featured);
        }
      } catch (err) {
        if (!cancelled) setError(err?.message || "Error authLoading pilots.");
      } finally {
        if (!cancelled) setAuthLoading(false);
      }
    }

    loadPilots();
    return () => {
      cancelled = true;
    };
  }, [query]);

  const sortedPilots = useMemo(() => {
    const rows = [...pilots];
    if (sortBy === "followers") {
      rows.sort((a, b) => Number(b.follower_count || 0) - Number(a.follower_count || 0));
    } else if (sortBy === "sales") {
      rows.sort((a, b) => Number(b.total_sales || 0) - Number(a.total_sales || 0));
    } else if (sortBy === "newest") {
      rows.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    } else {
      rows.sort((a, b) => Number(b.ranking_score || 0) - Number(a.ranking_score || 0));
    }
    return rows;
  }, [pilots, sortBy]);

  return (
    <div className="min-h-screen bg-[#0B0F14] text-slate-100">
      <PublicNav />
      <main className="mx-auto max-w-7xl px-4 py-8 md:px-8">
        <h1 className="text-3xl font-black tracking-tight md:text-4xl">Pilot Directory</h1>
        <p className="mt-2 text-sm text-slate-300">Search by pilot name, location, or slug.</p>

        <div className="relative mt-5 max-w-xl">
          <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search pilots..."
            className="h-11 w-full rounded-2xl border border-slate-800 bg-slate-900/80 pl-10 pr-4 text-sm outline-none transition focus:border-emerald-500"
          />
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          {[
            ["trending", "Trending"],
            ["followers", "Followers"],
            ["sales", "Sales"],
            ["newest", "Newest"],
          ].map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setSortBy(key)}
              className={`rounded-xl border px-3 py-1.5 text-xs font-bold ${
                sortBy === key
                  ? "border-emerald-500 bg-emerald-500/10 text-emerald-300"
                  : "border-slate-800 bg-slate-900 text-slate-300"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {!authLoading && !error && featuredPilots.length > 0 && (
          <section className="mt-6">
            <h2 className="text-xl font-black">Featured Pilots</h2>
            <div className="mt-3 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {featuredPilots.slice(0, 6).map((pilot) => (
                <PilotCard key={`featured-${pilot.id}`} pilot={pilot} />
              ))}
            </div>
          </section>
        )}

        {authLoading && (
          <div className="mt-6 rounded-2xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">Loading pilots...</div>
        )}
        {!authLoading && error && (
          <div className="mt-6 rounded-2xl border border-orange-500/30 bg-orange-500/10 p-4 text-sm text-orange-300">{error}</div>
        )}
        {!authLoading && !error && pilots.length === 0 && (
          <div className="mt-6 rounded-2xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">No pilots found.</div>
        )}
        {!authLoading && !error && sortedPilots.length > 0 && (
          <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {sortedPilots.map((pilot) => (
              <PilotCard key={pilot.id} pilot={pilot} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function DashboardApp() {
  const location = useLocation();
  const navigate = useNavigate();
  // Reuse the shared authentication hook.
  const { session, authLoading } = useAuthSession();
  const [user, setUser] = useState(null);
  const [pilotProfile, setPilotProfile] = useState(null);
  const [bootstrapping, setBootstrapping] = useState(false);
  const [bootstrapError, setBootstrapError] = useState("");
  const [active, setActive] = useState("overview");
  const [unreadCount, setUnreadCount] = useState(0);
  const initialThreadId = useMemo(
    () => new URLSearchParams(location.search).get("thread") || "",
    [location.search]
  );
  const title = useMemo(() => navItems.find((item) => item.id === active)?.label || "Overview", [active]);
  const activateTab = (tabId) => {
    setActive(tabId);
    if (tabId === "messages") {
      navigate("/dashboard/messages");
      return;
    }
    navigate("/dashboard");
  };

  useEffect(() => {
    if (location.pathname === "/dashboard/messages") {
      setActive("messages");
    }
  }, [location.pathname]);

  // Load the auth session using the shared hook; fallback to authLoading state.
  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return; }

    let cancelled = false;
    async function loadSession() {
      const { data } = await supabase.auth.getSession();
      if (!cancelled) { setSession(data?.session || null); setAuthLoading(false); }
    }
    loadSession();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!cancelled) { setSession(nextSession || null); setAuthLoading(false); }
    });

    return () => {
      cancelled = true;
      listener.subscription.unsubscribe();
    };
  }, []);



  useEffect(() => {
    if (!session || !supabase) return;

    let cancelled = false;
    async function bootstrapProfile() {
      setBootstrapping(true);
      setBootstrapError("");

      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (cancelled) return;
      if (userError || !userData?.user) {
        setBootstrapError(userError?.message || "Unable to load authenticated user.");
        setBootstrapping(false);
        return;
      }

      setUser(userData.user);

      try {
        const profile = await ensurePilotProfile(supabase, userData.user);
        if (!cancelled) setPilotProfile(profile);
      } catch (err) {
        if (!cancelled) setBootstrapError(err?.message || "Unable to load or create pilot profile.");
      } finally {
        if (!cancelled) setBootstrapping(false);
      }
    }

    bootstrapProfile();
    return () => {
      cancelled = true;
    };
  }, [session]);

  const handleLogout = async () => {
    if (!supabase) return;
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setPilotProfile(null);
    setUnreadCount(0);
    setBootstrapError("");
    setActive("overview");
    navigate("/login");
  };

  const handleSaveProfile = async (updates) => {
    if (!supabase || !user || !pilotProfile) {
      throw new Error("Session or profile not ready.");
    }

    const nextSlug = slugifyPilotName(updates.slug);
    const slugValidationError = validateSlug(nextSlug);
    if (slugValidationError) throw new Error(slugValidationError);

    let resolvedSlug = nextSlug;
    if (nextSlug !== pilotProfile.slug) {
      const { data: existingSlug, error: slugError } = await supabase
        .from("pilot_profiles")
        .select("id,user_id")
        .eq("slug", nextSlug)
        .maybeSingle();

      if (slugError) throw slugError;
      if (existingSlug && existingSlug.user_id !== user.id) {
        resolvedSlug = await generateUniqueSlug(supabase, nextSlug, user.id);
      }
    }

    const payload = {
      pilot_name: updates.pilot_name,
      slug: resolvedSlug,
      bio: updates.bio || "",
      location: updates.location || "",
      youtube_url: updates.youtube_url || "",
      instagram_url: updates.instagram_url || "",
      tiktok_url: updates.tiktok_url || "",
      cashapp_tag: updates.cashapp_tag || "",
      avatar_url: updates.avatar_url || "",
      banner_url: updates.banner_url || "",
    };

    const { data: saved, error } = await supabase
      .from("pilot_profiles")
      .update(payload)
      .eq("user_id", user.id)
      .select("*")
      .single();

    if (error) throw error;
    setPilotProfile(saved);
    return saved;
  };

  const refreshUnreadCount = async () => {
    if (!user?.id) {
      setUnreadCount(0);
      return;
    }
    try {
      const count = await getUnreadMessageCount(user.id);
      setUnreadCount(count);
    } catch (err) {
      console.warn("Unable to refresh unread count:", err?.message || err);
    }
  };

  useEffect(() => {
    refreshUnreadCount();
  }, [user?.id]);

  if (supabaseConfigError) {
    return <SetupScreen title="Supabase Setup Required" error={supabaseConfigError} />;
  }

  if (!session) return <AuthTest onAuthed={setSession} />;

  if (bootstrapping) {
    return (
      <SetupScreen
        title="Setting Up Your Pilot Profile"
        message="Loading your account and preparing profile defaults."
        authLoading
      />
    );
  }

  if (bootstrapError) {
    return (
      <SetupScreen
        title="Profile Setup Error"
        message="Your account is authenticated, but profile bootstrap failed."
        error={bootstrapError}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0F14] text-slate-100">
      <TopBar pilotProfile={pilotProfile} onLogout={handleLogout} unreadCount={unreadCount} onNavigate={activateTab} />
      <div className="flex">
        <Sidebar active={active} setActive={activateTab} pilotProfile={pilotProfile} unreadCount={unreadCount} />
        <main className="min-h-[calc(100vh-64px)] min-w-0 flex-1 px-4 py-6 md:px-8">
          <div className="mx-auto max-w-7xl">
            <PageHeader title={title} pilotProfile={pilotProfile} onNavigate={activateTab} />
            {active === "overview" && <Overview user={user} onNavigate={activateTab} />}
            {active === "store" && <StorePage user={user} pilotProfile={pilotProfile} />}
            {active === "content" && <ContentPage user={user} />}
            {active === "messages" && (
              <MessagesPage
                user={user}
                initialThreadId={initialThreadId}
                onUnreadCountRefresh={refreshUnreadCount}
              />
            )}
            {active === "settings" && (
              <SettingsPage user={user} pilotProfile={pilotProfile} onSave={handleSaveProfile} onNavigate={activateTab} />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

function TopBar({ pilotProfile, onLogout, unreadCount, onNavigate }) {
  const displayName = pilotProfile?.pilot_name || "Pilot";
  const unreadBadge = formatUnreadBadgeCount(unreadCount);
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center border-b border-slate-800 bg-[#0B0F14]/95 px-4 backdrop-blur md:px-6">
      <Link to="/" className="flex w-60 items-center gap-3 text-left">
        <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-emerald-500 font-black text-black">Q</div>
        <div>
          <div className="text-lg font-black tracking-tight">QuadRoster</div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-orange-400">Pilot Network</div>
        </div>
      </Link>
      <div className="hidden flex-1 justify-center md:flex">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
          <input
            className="h-10 w-full rounded-2xl border border-slate-800 bg-slate-900/80 pl-10 pr-4 text-sm outline-none transition focus:border-emerald-500"
            placeholder="Search pilots, products, orders..."
          />
        </div>
      </div>
      <div className="ml-auto flex items-center gap-2">
        <IconButton icon={Bell} onClick={() => onNavigate?.("messages")} />
        <IconButton icon={MessageSquare} badge={unreadBadge} onClick={() => onNavigate?.("messages")} />
        <button onClick={() => onNavigate?.("settings")} className="flex h-10 items-center gap-2 rounded-2xl border border-slate-800 bg-slate-900 px-3 text-sm hover:border-emerald-500">
          <User className="h-4 w-4" />
          <span className="hidden sm:inline">{displayName}</span>
        </button>
        <button
          onClick={onLogout}
          className="flex h-10 items-center gap-2 rounded-2xl border border-slate-800 bg-slate-900 px-3 text-sm hover:border-orange-500"
        >
          <LogOut className="h-4 w-4" />
          <span className="hidden sm:inline">Logout</span>
        </button>
      </div>
    </header>
  );
}

function IconButton({ icon: Icon, badge, onClick }) {
  return (
    <button onClick={onClick} className="relative flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-800 bg-slate-900 transition hover:border-emerald-500 hover:shadow-[0_0_20px_rgba(34,197,94,0.16)]">
      <Icon className="h-4 w-4" />
      {badge ? (
        <span className="absolute -right-1 -top-1 rounded-full bg-orange-500 px-1.5 py-0.5 text-[10px] font-black leading-none text-white">
          {badge}
        </span>
      ) : null}
    </button>
  );
}

function Sidebar({ active, setActive, pilotProfile, unreadCount }) {
  const displayName = pilotProfile?.pilot_name || "Pilot";
  const unreadBadge = formatUnreadBadgeCount(unreadCount);
  return (
    <aside className="sticky top-16 hidden h-[calc(100vh-64px)] w-60 border-r border-slate-800 bg-[#0F141B] p-4 md:block">
      <div className="mb-6 rounded-3xl border border-slate-800 bg-slate-950/50 p-4">
        <div className="text-sm font-semibold">{displayName}</div>
        <div className="mt-1 text-xs text-slate-400">Free Plan · 5 products</div>
        <button onClick={() => setActive("settings")} className="mt-3 w-full rounded-xl bg-orange-500 px-3 py-2 text-xs font-bold text-black transition hover:bg-orange-400">Upgrade Pro</button>
      </div>
      <nav className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActive(item.id)}
              className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition ${
                isActive ? "bg-slate-800 text-emerald-400" : "text-slate-300 hover:bg-slate-900 hover:text-white"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span>{item.label}</span>
              {item.id === "messages" && unreadBadge ? (
                <span className="ml-auto rounded-full bg-orange-500 px-2 py-0.5 text-[10px] font-black leading-none text-white">
                  {unreadBadge}
                </span>
              ) : null}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}

function PageHeader({ title, pilotProfile, onNavigate }) {
  const storefrontHref = pilotProfile?.slug ? `/p/${pilotProfile.slug}` : null;
  const goToOrders = () => {
    onNavigate?.("store");
    window.setTimeout(() => {
      const ordersPanel = document.getElementById("store-orders-panel");
      if (!ordersPanel) return;
      ordersPanel.scrollIntoView({ behavior: "smooth", block: "start" });
      ordersPanel.focus({ preventScroll: true });
    }, 120);
  };
  const shareStorefront = async () => {
    if (!storefrontHref) return;
    const shareUrl = `${window.location.origin}${storefrontHref}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "QuadRoster Storefront", url: shareUrl });
        return;
      } catch {
        // fall through to clipboard
      }
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      window.alert("Storefront link copied.");
    } catch {
      window.alert(shareUrl);
    }
  };
  return (
    <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
      <div>
        <h1 className="text-3xl font-black tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-slate-400">Build your FPV brand, showcase your flying, and sell merch.</p>
      </div>
      <div className="flex w-full flex-wrap gap-2 sm:w-auto sm:justify-end">
        <a
          href={storefrontHref || "#"}
          className={`rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 text-sm font-bold hover:border-emerald-500 ${
            storefrontHref ? "" : "pointer-events-none opacity-60"
          }`}
        >
          View Storefront
        </a>
        <button
          onClick={goToOrders}
          className="rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 text-sm font-bold hover:border-emerald-500"
        >
          View Orders
        </button>
        <button onClick={shareStorefront} className="flex items-center gap-2 rounded-2xl bg-emerald-500 px-4 py-2 text-sm font-black text-black hover:bg-emerald-400">
          <Share2 className="h-4 w-4" /> Share Page
        </button>
      </div>
    </div>
  );
}

function Overview({ user, onNavigate }) {
  const [statsData, setStatsData] = useState({
    revenue: 0,
    paidOrders: 0,
    products: 0,
    availableEarnings: 0,
    topProductName: "No product yet",
    topProductImageUrl: "",
    topProductSales: 0,
    topProductRevenue: 0,
  });
  const [revenueSeries, setRevenueSeries] = useState(() => getLast7DayRevenueData([]));
  const [activityItems, setActivityItems] = useState([]);
  const [overviewError, setOverviewError] = useState("");

  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;

    async function loadOverview() {
      try {
        const [orders, products, earnings] = await Promise.all([
          getOrders(user.id),
          getProducts(user.id),
          getPilotEarnings(user.id),
        ]);
        if (cancelled) return;

        const commerceOrders = (orders || []).filter((row) => {
          const status = String(row.status || "").toLowerCase();
          return Boolean(row.stripe_session_id) || ["pending_payment", "paid", "failed"].includes(status);
        });
        const paidOrders = commerceOrders.filter((row) => String(row.status || "").toLowerCase() === "paid");
        const revenue = paidOrders.reduce((sum, row) => sum + Number(row.amount || 0), 0);
        const availableEarnings = (earnings || [])
          .filter((row) => String(row.status || "").toLowerCase() === "available")
          .reduce((sum, row) => sum + Number(row.amount || 0), 0);
        const topProduct = [...(products || [])].sort(
          (a, b) => Number(b.sales_count || 0) - Number(a.sales_count || 0)
        )[0];

        setStatsData({
          revenue,
          paidOrders: paidOrders.length,
          products: (products || []).length,
          availableEarnings,
          topProductName: topProduct?.name || "No product yet",
          topProductImageUrl: topProduct?.image_url || "",
          topProductSales: Number(topProduct?.sales_count || 0),
          topProductRevenue: Number(topProduct?.price || 0) * Number(topProduct?.sales_count || 0),
        });
        setRevenueSeries(getLast7DayRevenueData(commerceOrders || []));
        const recentPaid = (commerceOrders || [])
          .filter((row) => String(row.status || "").toLowerCase() === "paid")
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
          .slice(0, 3)
          .map((row) => ({
            id: `order-${row.id}`,
            text: `Paid order ${row.order_number || row.id} · ${money(getOrderTotal(row))}`,
            at: row.created_at,
          }));
        const recentEarnings = (earnings || [])
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
          .slice(0, 3)
          .map((row) => ({
            id: `earn-${row.id}`,
            text: `Earnings ${row.status || "pending"} · ${money(row.amount)}`,
            at: row.created_at,
          }));
        const merged = [...recentPaid, ...recentEarnings]
          .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
          .slice(0, 4);
        setActivityItems(merged);
      } catch (err) {
        if (!cancelled) {
          setOverviewError(err?.message || "Unable to load overview metrics.");
        }
      }
    }

    loadOverview();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const dynamicStats = [
    { label: "Revenue", value: money(statsData.revenue), delta: "gross", icon: DollarSign },
    { label: "Paid Orders", value: String(statsData.paidOrders), delta: "completed", icon: ShoppingBag },
    { label: "Products", value: String(statsData.products), delta: "active + inactive", icon: Package },
    { label: "Available Earnings", value: money(statsData.availableEarnings), delta: "ready for payout", icon: Users },
  ];

  return (
    <div className="space-y-6">
      {overviewError && <div className="rounded-2xl bg-orange-500/10 p-3 text-sm text-orange-300">{overviewError}</div>}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {dynamicStats.map((stat) => (
          <StatCard key={stat.label} {...stat} />
        ))}
      </div>
      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <Card title="Revenue Performance" action="Last 7 days">
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={revenueSeries}>
                <XAxis dataKey="day" stroke="#64748b" fontSize={12} />
                <YAxis stroke="#64748b" fontSize={12} />
                <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 12 }} />
                <Line type="monotone" dataKey="revenue" stroke="#22C55E" strokeWidth={3} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Latest Activity">
          <div className="space-y-3">
            {(activityItems.length ? activityItems : [{ id: "empty", text: "No recent activity yet." }]).map((item) => (
              <div key={item.id} className="flex items-center gap-3 rounded-2xl bg-slate-950/60 p-3 text-sm">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                {item.text}
              </div>
            ))}
          </div>
        </Card>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Top Product">
          <div className="flex items-center gap-5">
            <MockProduct type="Hoodie" imageUrl={statsData.topProductImageUrl} />
            <div>
              <h3 className="text-xl font-black">{statsData.topProductName}</h3>
              <p className="mt-1 text-sm text-slate-400">
                {statsData.topProductSales} sold · {money(statsData.topProductRevenue)} gross revenue
              </p>
              <button onClick={() => onNavigate?.("store")} className="mt-4 rounded-2xl border border-slate-700 px-4 py-2 text-sm font-bold hover:border-emerald-500">Edit Product</button>
            </div>
          </div>
        </Card>
        <Card title="Quick Actions">
          <div className="grid gap-3 sm:grid-cols-2">
            {[["Add Product", "store"], ["Add Video", "content"], ["Connect Social", "settings"], ["View Analytics", "overview"]].map(([label, tabId]) => (
              <button key={label} onClick={() => onNavigate?.(tabId)} className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-950/60 p-4 text-left font-bold hover:border-orange-500">
                {label}
                <Plus className="h-4 w-4 text-orange-400" />
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ label, value, delta, icon: Icon }) {
  return (
    <motion.div whileHover={{ y: -3 }} className="rounded-3xl border border-slate-800 bg-[#111827] p-5 shadow-xl shadow-black/20">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold text-slate-400">{label}</div>
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-emerald-400">
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <div className="mt-4 text-3xl font-black">{value}</div>
      <div className="mt-1 text-xs font-bold text-emerald-400">{delta} this month</div>
    </motion.div>
  );
}

function Card({ title, action, children }) {
  return (
    <section className="min-w-0 rounded-3xl border border-slate-800 bg-[#111827] p-5 shadow-xl shadow-black/20">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-black">{title}</h2>
        {action && <span className="rounded-full bg-slate-950 px-3 py-1 text-xs text-slate-400">{action}</span>}
      </div>
      {children}
    </section>
  );
}

function StorePage({ user, pilotProfile }) {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [earnings, setEarnings] = useState([]);
  const [payouts, setPayouts] = useState([]);
  const [cashappTag, setCashappTag] = useState("");
  const [payoutSaving, setPayoutSaving] = useState(false);
  const [payoutMessage, setPayoutMessage] = useState("");
  const [authLoadingProducts, setAuthLoadingProducts] = useState(false);
  const [productsError, setProductsError] = useState("");
  const [fulfillmentSavingOrderId, setFulfillmentSavingOrderId] = useState("");
  const [fulfillmentJobs, setFulfillmentJobs] = useState([]);
  const [fulfillmentMessage, setFulfillmentMessage] = useState("");
  const [expandedOrderId, setExpandedOrderId] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [createForm, setCreateForm] = useState({
    name: "",
    product_type: "T-Shirt",
    price: "0",
    design_image_url: "",
    design_storage_path: "",
    design_original_filename: "",
    image_url: "",
    print_area: "front",
  });
  const [createSaving, setCreateSaving] = useState(false);
  const [createImageUpauthLoading, setCreateImageUpauthLoading] = useState(false);
  const [createError, setCreateError] = useState("");
  const [mobileOpenSections, setMobileOpenSections] = useState({
    recentOrders: true,
    fulfillmentStatus: true,
    fulfillmentJobs: false,
    earnings: false,
  });
  const [selectedFulfillmentProviderByOrder, setSelectedFulfillmentProviderByOrder] = useState({});

  const toggleMobileSection = (key) => {
    setMobileOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;

    async function loadProducts() {
      setAuthLoadingProducts(true);
      setProductsError("");
      try {
        const [productData, orderData, earningsData, fulfillmentJobData, payoutData] = await Promise.all([
          getProducts(user.id),
          getOrders(user.id),
          getPilotEarnings(user.id),
          getPilotFulfillmentJobs(user.id),
          getPilotPayouts(user.id),
        ]);
        if (!cancelled) {
          setProducts(productData);
          setOrders(orderData);
          setEarnings(earningsData);
          setFulfillmentJobs(fulfillmentJobData);
          setPayouts(payoutData);
        }
      } catch (err) {
        if (!cancelled) setProductsError(err?.message || "Unable to load products.");
      } finally {
        if (!cancelled) setAuthLoadingProducts(false);
      }
    }

    loadProducts();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  useEffect(() => {
    setCashappTag(pilotProfile?.cashapp_tag || "");
  }, [pilotProfile?.cashapp_tag]);

  const onCreateChange = (field) => (event) => {
    setCreateForm((prev) => ({ ...prev, [field]: event.target.value }));
  };

  const submitCreate = async (event) => {
    event.preventDefault();
    if (!user?.id) return;
    if (!createForm.name.trim()) {
      setCreateError("Product name is required.");
      return;
    }

    try {
      setCreateSaving(true);
      setCreateError("");
      const created = await createProduct({
        ...(() => {
          const defaults = getPrintifyDefaultsForType(createForm.product_type);
          return {
            printify_blueprint_id: defaults.blueprintId,
            printify_print_provider_id: defaults.printProviderId,
            printify_variant_id: defaults.variantId,
          };
        })(),
        user_id: user.id,
        name: createForm.name.trim(),
        product_type: createForm.product_type,
        price: createForm.price,
        profit: "0",
        image_url: createForm.image_url || null,
        design_image_url: createForm.design_image_url || null,
        design_storage_path: createForm.design_storage_path || null,
        design_original_filename: createForm.design_original_filename || null,
        print_area: createForm.print_area || "front",
        is_printify_ready: Boolean(
          getPrintifyReadiness({
            ...createForm,
            ...getPrintifyDefaultsForType(createForm.product_type),
          }).ready
        ),
      });
      setProducts((prev) => [created, ...prev]);
      setCreateForm({
        name: "",
        product_type: "T-Shirt",
        price: "0",
        design_image_url: "",
        design_storage_path: "",
        design_original_filename: "",
        image_url: "",
        print_area: "front",
      });
      setShowCreateForm(false);
    } catch (err) {
      setCreateError(err?.message || "Unable to create product.");
    } finally {
      setCreateSaving(false);
    }
  };

  const handleToggleActive = async (product) => {
    const previousActive = product.active;
    setProducts((prev) => prev.map((item) => (item.id === product.id ? { ...item, active: !previousActive } : item)));
    try {
      const saved = await updateProduct(product.id, { active: !previousActive });
      setProducts((prev) => prev.map((item) => (item.id === product.id ? saved : item)));
    } catch (err) {
      setProducts((prev) => prev.map((item) => (item.id === product.id ? { ...item, active: previousActive } : item)));
      setProductsError(err?.message || "Unable to update product status.");
    }
  };

  const handleSaveEdit = async (productId, updates) => {
    const saved = await updateProduct(productId, updates);
    setProducts((prev) => prev.map((item) => (item.id === productId ? saved : item)));
    return saved;
  };

  const handleDelete = async (productId) => {
    if (!window.confirm("Delete this product?")) return;
    const original = products;
    setProducts((prev) => prev.filter((item) => item.id !== productId));
    try {
      await deleteProduct(productId);
    } catch (err) {
      setProducts(original);
      setProductsError(err?.message || "Unable to delete product.");
    }
  };

  const handleCreateImageUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file || !user?.id) return;
    try {
      setCreateImageUpauthLoading(true);
      setCreateError("");
      const uploaded = await uploadProductImage(user.id, file, { bucket: "product-designs", productRef: "temp" });
      setCreateForm((prev) => ({
        ...prev,
        image_url: uploaded.publicUrl,
        design_image_url: uploaded.publicUrl,
        design_storage_path: uploaded.storagePath,
        design_original_filename: uploaded.originalFilename || "",
      }));
    } catch (err) {
      setCreateError(err?.message || "Unable to upload image.");
    } finally {
      setCreateImageUpauthLoading(false);
      event.target.value = "";
    }
  };

  const handleSendToFulfillment = async (order) => {
    if (!order?.id || fulfillmentSavingOrderId) return;
    const orderStatus = String(order.status || "").toLowerCase();
    const fulfillmentStatus = String(order.fulfillment_status || "pending").toLowerCase();
    if (orderStatus !== "paid" || fulfillmentStatus !== "pending") return;

    const previous = orders;
    const providerKey = selectedFulfillmentProviderByOrder[order.id] || "mock";
    setFulfillmentSavingOrderId(order.id);
    setFulfillmentMessage("");
    try {
      await submitFulfillmentOrder(order.id, providerKey);
      const [nextOrders, nextJobs] = await Promise.all([getOrders(user.id), getPilotFulfillmentJobs(user.id)]);
      setOrders(nextOrders);
      setFulfillmentJobs(nextJobs);
      setFulfillmentMessage(`Order sent to ${providerKey} fulfillment provider.`);
    } catch (err) {
      setOrders(previous);
      setFulfillmentMessage(err?.message || "Unable to submit fulfillment.");
    } finally {
      setFulfillmentSavingOrderId("");
    }
  };

  const handleRequestPayout = async () => {
    if (!user?.id || payoutSaving) return;
    setPayoutMessage("");
    if (!validateCashAppTag(cashappTag)) {
      setPayoutMessage("CashApp tag must start with $ and be 2-30 characters using letters, numbers, or underscore.");
      return;
    }

    try {
      setPayoutSaving(true);
      const { error: cashappSaveError } = await supabase
        .from("pilot_profiles")
        .update({ cashapp_tag: cashappTag.trim() })
        .eq("user_id", user.id);
      if (cashappSaveError) throw cashappSaveError;

      const payout = await requestPilotPayout({ userId: user.id, cashappTag });
      const [nextEarnings, nextPayouts] = await Promise.all([
        getPilotEarnings(user.id),
        getPilotPayouts(user.id),
      ]);
      setEarnings(nextEarnings);
      setPayouts(nextPayouts);
      setPayoutMessage(`Payout request submitted. Payment will be sent to ${payout.cashapp_tag}.`);
    } catch (err) {
      setPayoutMessage(err?.message || "Unable to request payout.");
    } finally {
      setPayoutSaving(false);
    }
  };

  const earningsSummary = useMemo(() => {
    const totals = earnings.reduce(
      (acc, row) => {
        const amount = Number(row.amount || 0);
        acc.total += amount;
        if (row.status === "pending") acc.pending += amount;
        if (row.status === "available") acc.available += amount;
        return acc;
      },
      { total: 0, pending: 0, available: 0 }
    );
    return totals;
  }, [earnings]);
  const payoutSummary = useMemo(() => {
    const totalEarned = (earnings || []).reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const available = (earnings || [])
      .filter((row) => String(row.payout_status || "unpaid").toLowerCase() === "unpaid")
      .reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const pending = (payouts || [])
      .filter((row) => String(row.status || "").toLowerCase() === "pending")
      .reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const paid = (payouts || [])
      .filter((row) => String(row.status || "").toLowerCase() === "paid")
      .reduce((sum, row) => sum + Number(row.amount || 0), 0);
    return { totalEarned, available, pending, paid };
  }, [earnings, payouts]);
  const commerceOrders = useMemo(
    () =>
      (orders || []).filter((row) => {
        const status = String(row.status || "").toLowerCase();
        return Boolean(row.stripe_session_id) || ["pending_payment", "paid", "failed"].includes(status);
      }),
    [orders]
  );

  return (
    <div className="max-w-full space-y-6 overflow-x-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-black">Your Products</h2>
        <button
          onClick={() => setShowCreateForm((prev) => !prev)}
          className="flex items-center gap-2 rounded-2xl bg-emerald-500 px-4 py-2 text-sm font-black text-black"
        >
          <Plus className="h-4 w-4" /> Add Product
        </button>
      </div>

      {showCreateForm && (
        <Card title="Create Product">
          <form onSubmit={submitCreate} className="grid gap-3 md:grid-cols-2">
            <input
              className="h-12 rounded-2xl border border-slate-800 bg-slate-950 px-4 outline-none focus:border-emerald-500"
              placeholder="Product name"
              value={createForm.name}
              onChange={onCreateChange("name")}
            />
            <select
              className="h-12 rounded-2xl border border-slate-800 bg-slate-950 px-4 outline-none focus:border-emerald-500"
              value={createForm.product_type}
              onChange={onCreateChange("product_type")}
            >
              {productTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
            <input
              className="h-12 rounded-2xl border border-slate-800 bg-slate-950 px-4 outline-none focus:border-emerald-500"
              placeholder="Retail price"
              type="number"
              min="0"
              step="0.01"
              value={createForm.price}
              onChange={onCreateChange("price")}
            />
            <input
              className="h-12 rounded-2xl border border-slate-800 bg-slate-950 px-4 outline-none focus:border-emerald-500"
              placeholder="Design image URL (optional fallback)"
              value={createForm.design_image_url}
              onChange={onCreateChange("design_image_url")}
            />
            <div className="flex items-center rounded-2xl border border-slate-800 bg-slate-950 px-4 text-sm text-slate-300">
              Pilot earnings are calculated automatically at 90% of subtotal.
            </div>
            <div className="flex items-center rounded-2xl border border-slate-800 bg-slate-950 px-4 text-xs text-slate-400">
              Printify fulfillment requires a publicly accessible design image URL.
            </div>
            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3 text-xs text-slate-300">
              <div className="font-bold text-slate-200">Printify readiness</div>
              {(() => {
                const ready = getPrintifyReadiness(createForm);
                return (
                  <div className="mt-2 space-y-1">
                    <div>{ready.typeSupported ? "✓" : "✗"} Product type supported</div>
                    <div>{ready.hasPrice ? "✓" : "✗"} Retail price set</div>
                    <div>{ready.hasDesign ? "✓" : "✗"} Design image added</div>
                    <div>{ready.defaultsConfigured ? "✓" : "✗"} Platform Printify defaults configured</div>
                    <div className={`pt-1 font-bold ${ready.ready ? "text-emerald-300" : "text-orange-300"}`}>
                      {ready.ready ? "Ready for Printify" : (ready.hasDesign ? "Platform Printify defaults not configured" : "Missing design image")}
                    </div>
                  </div>
                );
              })()}
            </div>
            <div className="md:col-span-2 rounded-2xl border border-slate-800 bg-slate-950 p-3">
              <label className="mb-2 block text-xs font-bold text-slate-400">Upload logo/design</label>
              <input type="file" accept=".png,.jpg,.jpeg,.svg,.webp,image/png,image/jpeg,image/svg+xml,image/webp" onChange={handleCreateImageUpload} className="text-xs text-slate-300" />
              {createImageUpauthLoading && <div className="mt-2 text-xs text-slate-400">UpauthLoading image...</div>}
              {createForm.design_image_url && (
                <img src={createForm.design_image_url} alt="Design preview" className="mt-3 h-24 w-24 rounded-xl border border-slate-700 object-cover" />
              )}
            </div>
            {createError && <div className="md:col-span-2 text-sm text-orange-300">{createError}</div>}
            <div className="md:col-span-2 flex gap-2">
              <button
                disabled={createSaving}
                className="rounded-2xl bg-emerald-500 px-4 py-2 text-sm font-black text-black disabled:opacity-60"
              >
                {createSaving ? "Saving..." : "Create"}
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 text-sm font-bold"
              >
                Cancel
              </button>
            </div>
          </form>
        </Card>
      )}

      {productsError && <div className="rounded-2xl bg-orange-500/10 p-3 text-sm text-orange-300">{productsError}</div>}
      {authLoadingProducts && <div className="rounded-2xl bg-slate-900 p-4 text-sm text-slate-300">Loading products...</div>}
      {!authLoadingProducts && products.length === 0 && (
        <div className="rounded-2xl bg-slate-900 p-4 text-sm text-slate-300">No products yet. Create your first product.</div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            userId={user.id}
            product={product}
            onToggleActive={() => handleToggleActive(product)}
            onSaveEdit={handleSaveEdit}
            onDelete={() => handleDelete(product.id)}
          />
        ))}
      </div>
      <div className="md:hidden">
        <button
          type="button"
          onClick={() => toggleMobileSection("recentOrders")}
          className="w-full rounded-2xl border border-slate-800 bg-slate-950 px-4 py-2 text-left text-sm font-bold"
        >
          Recent Orders {mobileOpenSections.recentOrders ? "−" : "+"}
        </button>
      </div>
      <div className={`${mobileOpenSections.recentOrders ? "block" : "hidden"} md:block`}>
      <Card title="Recent Orders">
        <div className="space-y-3 md:hidden">
          {commerceOrders.length === 0 && (
            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-sm text-slate-400">No orders yet.</div>
          )}
          {commerceOrders.map((order) => {
            const items = Array.isArray(order.order_items) ? order.order_items : [];
            const subtotal = getOrderSubtotal(order);
            const shipping = getOrderShipping(order);
            const totalPaid = getOrderTotal(order);
            const isExpanded = expandedOrderId === order.id;
            return (
              <div key={order.id} className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
                <div className="flex items-start justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => navigator.clipboard?.writeText(order.id)}
                    className="font-mono text-xs font-bold text-slate-200 hover:text-emerald-400"
                    title="Copy full order id"
                  >
                    {shortId(order.order_number || order.id)}
                  </button>
                  <button
                    type="button"
                    onClick={() => setExpandedOrderId(isExpanded ? "" : order.id)}
                    className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-bold hover:border-emerald-500"
                  >
                    {isExpanded ? "Hide" : "View"}
                  </button>
                </div>
                <div className="mt-2 text-sm">
                  <div className="truncate font-bold">{order.product_name || items[0]?.product_name || "-"}</div>
                  <div className="truncate text-slate-300">{order.buyer_name || "-"}</div>
                  <div className="truncate text-xs text-slate-400">{order.buyer_email || "-"}</div>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-2">
                    <div className="text-slate-400">Subtotal</div>
                    <div className="font-bold">{money(subtotal)}</div>
                  </div>
                  <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-2">
                    <div className="text-slate-400">Shipping</div>
                    <div className="font-bold">{money(shipping)}</div>
                  </div>
                  <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-2">
                    <div className="text-slate-400">Total Paid</div>
                    <div className="font-bold">{money(totalPaid)}</div>
                  </div>
                  <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-2">
                    <div className="text-slate-400">Pilot Earnings</div>
                    <div className="font-bold">{money(order.pilot_earnings)}</div>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <Status label={order.status || "Processing"} />
                  <Status label={order.fulfillment_status || "pending"} />
                </div>
                <div className="mt-2 text-xs text-slate-400">
                  {order.created_at ? new Date(order.created_at).toLocaleDateString() : "-"}
                </div>
                {isExpanded && (
                  <div className="mt-3 border-t border-slate-800 pt-3 text-sm text-slate-300">
                    <div><span className="text-slate-400">Order ID:</span> <span className="font-mono text-xs break-all">{order.id}</span></div>
                    <div><span className="text-slate-400">Stripe Session:</span> <span className="font-mono text-xs break-all">{order.stripe_session_id || "-"}</span></div>
                    <div><span className="text-slate-400">Shipping:</span> {formatShippingAddress(order) || "-"}</div>
                    <div className="mt-2"><span className="text-slate-400">QuadRoster Fee:</span> {money(order.platform_fee)}</div>
                    <div><span className="text-slate-400">Pilot Earnings:</span> {money(order.pilot_earnings)}</div>
                    <div className="mt-2 text-xs font-bold uppercase tracking-wide text-slate-400">Items</div>
                    <div className="space-y-1">
                      {(items.length ? items : [{
                        id: `${order.id}-fallback`,
                        product_name: order.product_name,
                        quantity: order.quantity,
                        line_total: subtotal,
                      }]).map((item) => (
                        <div key={item.id} className="text-sm">
                          {item.product_name || "Product"} · qty {Number(item.quantity || 1)} · {money(item.line_total ?? item.total_price ?? subtotal)}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="hidden w-full max-w-full overflow-x-auto rounded-2xl border border-slate-800 md:block">
          <table className="w-full min-w-[760px] md:min-w-[1180px] text-left text-sm">
            <thead className="bg-slate-950 text-slate-400">
              <tr>
                <th className="p-4">Order</th>
                <th className="p-4">Buyer</th>
                <th className="hidden p-4 md:table-cell">Email</th>
                <th className="p-4">Product</th>
                <th className="p-4">Qty</th>
                <th className="p-4">Subtotal</th>
                <th className="hidden p-4 md:table-cell">Shipping</th>
                <th className="p-4">Total Paid</th>
                <th className="hidden p-4 lg:table-cell">QuadRoster Fee</th>
                <th className="hidden p-4 lg:table-cell">Pilot Earnings</th>
                <th className="hidden p-4 md:table-cell">Payment</th>
                <th className="hidden p-4 md:table-cell">Fulfillment</th>
                <th className="hidden p-4 md:table-cell">Date</th>
                <th className="p-4">Details</th>
              </tr>
            </thead>
            <tbody>
              {commerceOrders.length === 0 && (
                <tr className="border-t border-slate-800">
                  <td className="p-4 text-slate-400" colSpan={14}>No orders yet.</td>
                </tr>
              )}
              {commerceOrders.map((order) => {
                const isExpanded = expandedOrderId === order.id;
                const items = Array.isArray(order.order_items) ? order.order_items : [];
                const subtotal = getOrderSubtotal(order);
                const shipping = getOrderShipping(order);
                const totalPaid = getOrderTotal(order);
                return (
                  <React.Fragment key={order.id}>
                    <tr className="border-t border-slate-800">
                      <td className="p-4 font-bold">
                        <button
                          type="button"
                          onClick={() => navigator.clipboard?.writeText(order.id)}
                          title="Click to copy full order id"
                          className="max-w-[140px] truncate text-left hover:text-emerald-400"
                        >
                          {shortId(order.order_number || order.id)}
                        </button>
                      </td>
                      <td className="p-4">
                        <div className="max-w-[140px] truncate">{order.buyer_name || "-"}</div>
                      </td>
                      <td className="hidden p-4 md:table-cell">
                        <div className="max-w-[220px] truncate">{order.buyer_email || "-"}</div>
                      </td>
                      <td className="p-4">
                        <div className="max-w-[180px] truncate">{order.product_name || items[0]?.product_name || "-"}</div>
                      </td>
                      <td className="p-4">{Number(order.quantity || items[0]?.quantity || 1)}</td>
                      <td className="p-4 font-bold">{money(subtotal)}</td>
                      <td className="hidden p-4 font-bold md:table-cell">{money(shipping)}</td>
                      <td className="p-4 font-bold">{money(totalPaid)}</td>
                      <td className="hidden p-4 font-bold lg:table-cell">{money(order.platform_fee)}</td>
                      <td className="hidden p-4 font-bold lg:table-cell">{money(order.pilot_earnings)}</td>
                      <td className="hidden p-4 md:table-cell"><Status label={order.status || "Processing"} /></td>
                      <td className="hidden p-4 md:table-cell"><Status label={order.fulfillment_status || "pending"} /></td>
                      <td className="hidden p-4 text-slate-400 md:table-cell">{order.created_at ? new Date(order.created_at).toLocaleDateString() : "-"}</td>
                      <td className="p-4">
                        <button
                          type="button"
                          onClick={() => setExpandedOrderId(isExpanded ? "" : order.id)}
                          className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-bold hover:border-emerald-500"
                        >
                          {isExpanded ? "Hide" : "View"}
                        </button>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="border-t border-slate-900 bg-slate-950/40">
                        <td className="p-4 text-sm text-slate-300" colSpan={14}>
                          <div className="grid gap-4 md:grid-cols-2">
                            <div className="space-y-1">
                              <div><span className="text-slate-400">Order ID:</span> <span className="font-mono text-xs break-all">{order.id}</span></div>
                              <div><span className="text-slate-400">Stripe Session:</span> <span className="font-mono text-xs break-all">{order.stripe_session_id || "-"}</span></div>
                              <div><span className="text-slate-400">Buyer:</span> {order.buyer_name || "-"}</div>
                              <div><span className="text-slate-400">Buyer Email:</span> {order.buyer_email || "-"}</div>
                              <div><span className="text-slate-400">Shipping:</span> {formatShippingAddress(order) || "-"}</div>
                            </div>
                            <div className="space-y-1">
                              <div><span className="text-slate-400">Subtotal:</span> {money(subtotal)}</div>
                              <div><span className="text-slate-400">Shipping:</span> {money(shipping)}</div>
                              <div><span className="text-slate-400">Total:</span> {money(totalPaid)}</div>
                              <div><span className="text-slate-400">Platform Fee:</span> {money(order.platform_fee)}</div>
                              <div><span className="text-slate-400">Pilot Earnings:</span> {money(order.pilot_earnings)}</div>
                              <div><span className="text-slate-400">Fulfillment:</span> {order.fulfillment_status || "pending"}</div>
                              <div><span className="text-slate-400">Fulfillment ID:</span> <span className="font-mono text-xs break-all">{order.fulfillment_id || "-"}</span></div>
                            </div>
                          </div>
                          <div className="mt-4">
                            <div className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-400">Order Items</div>
                            <div className="space-y-1 text-sm">
                              {(items.length ? items : [{
                                id: `${order.id}-fallback`,
                                product_name: order.product_name,
                                quantity: order.quantity,
                                line_total: order.amount,
                              }]).map((item) => (
                                <div key={item.id} className="flex flex-wrap items-center gap-2">
                                  <span className="font-bold">{item.product_name || "Product"}</span>
                                  <span className="text-slate-400">qty {Number(item.quantity || 1)}</span>
                                  <span className="text-slate-400">line {money(item.line_total ?? item.total_price ?? subtotal)}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
      </div>

      <div id="store-orders-panel" tabIndex={-1} className="outline-none">
      <div className="md:hidden">
        <button
          type="button"
          onClick={() => toggleMobileSection("fulfillmentStatus")}
          className="mb-3 w-full rounded-2xl border border-slate-800 bg-slate-950 px-4 py-2 text-left text-sm font-bold"
        >
          Fulfillment Status {mobileOpenSections.fulfillmentStatus ? "−" : "+"}
        </button>
      </div>
      <div className={`${mobileOpenSections.fulfillmentStatus ? "block" : "hidden"} md:block`}>
      <Card title="Fulfillment Status">
        <div className="space-y-3 md:hidden">
          {commerceOrders.length === 0 && (
            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-sm text-slate-400">No orders yet.</div>
          )}
          {commerceOrders.map((order) => {
            const current = String(order.fulfillment_status || "pending").toLowerCase();
            const paymentStatus = String(order.status || "").toLowerCase();
            const updatedAt = order.delivered_at || order.shipped_at || order.created_at;
            const canSend = paymentStatus === "paid" && current === "pending";
            const product = products.find((row) => row.id === order.product_id);
            const isPrintifyReady = getPrintifyReadiness(product || order).ready;
            const providerKey = selectedFulfillmentProviderByOrder[order.id] || "mock";
            return (
              <div key={order.id} className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-mono text-xs font-bold text-slate-200">{shortId(order.order_number || order.id)}</div>
                    <div className="mt-1 truncate text-sm font-bold">{order.product_name || order.order_items?.[0]?.product_name || "-"}</div>
                    <div className="truncate text-sm text-slate-300">{order.buyer_name || "-"}</div>
                    <div className="truncate text-xs text-slate-400">{[order.shipping_city, order.shipping_state].filter(Boolean).join(", ") || "-"}</div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <select
                      value={providerKey}
                      onChange={(event) =>
                        setSelectedFulfillmentProviderByOrder((prev) => ({ ...prev, [order.id]: event.target.value }))
                      }
                      className="h-8 rounded-xl border border-slate-700 bg-slate-900 px-2 text-xs"
                    >
                      {fulfillmentProviderOptions.map((option) => (
                        <option key={option.key} value={option.key} disabled={option.key === "printify" && !isPrintifyReady}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={() => handleSendToFulfillment(order)}
                      disabled={!canSend || fulfillmentSavingOrderId === order.id || (providerKey === "printify" && !isPrintifyReady)}
                      className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-bold hover:border-emerald-500 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {fulfillmentSavingOrderId === order.id ? "Sending..." : "Send"}
                    </button>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <Status label={paymentStatus || "pending_payment"} />
                  <Status label={current} />
                </div>
                <div className="mt-2 text-xs text-slate-400">{updatedAt ? new Date(updatedAt).toLocaleString() : "-"}</div>
              </div>
            );
          })}
        </div>

        <div className="hidden w-full max-w-full overflow-x-auto rounded-2xl border border-slate-800 md:block">
          <table className="w-full min-w-[700px] md:min-w-[980px] text-left text-sm">
            <thead className="bg-slate-950 text-slate-400">
              <tr>
                <th className="p-4">Order</th>
                <th className="p-4">Product</th>
                <th className="p-4">Buyer</th>
                <th className="hidden p-4 md:table-cell">Destination</th>
                <th className="hidden p-4 md:table-cell">Payment</th>
                <th className="hidden p-4 md:table-cell">Fulfillment</th>
                <th className="hidden p-4 md:table-cell">Updated</th>
                <th className="p-4">Action</th>
              </tr>
            </thead>
            <tbody>
              {commerceOrders.length === 0 && (
                <tr className="border-t border-slate-800">
                  <td className="p-4 text-slate-400" colSpan={8}>No orders yet.</td>
                </tr>
              )}
              {commerceOrders.map((order) => {
                const current = String(order.fulfillment_status || "pending").toLowerCase();
                const paymentStatus = String(order.status || "").toLowerCase();
                const updatedAt = order.delivered_at || order.shipped_at || order.created_at;
                const canSend = paymentStatus === "paid" && current === "pending";
                const product = products.find((row) => row.id === order.product_id);
                const isPrintifyReady = getPrintifyReadiness(product || order).ready;
                const providerKey = selectedFulfillmentProviderByOrder[order.id] || "mock";
                return (
                  <tr key={order.id} className="border-t border-slate-800">
                    <td className="p-4 font-bold">
                      <div className="max-w-[200px] truncate">{order.order_number || order.id}</div>
                    </td>
                    <td className="p-4">
                      <div className="max-w-[170px] truncate">{order.product_name || order.order_items?.[0]?.product_name || "-"}</div>
                    </td>
                    <td className="p-4">
                      <div className="max-w-[150px] truncate">{order.buyer_name || "-"}</div>
                    </td>
                    <td className="hidden p-4 text-slate-300 md:table-cell">
                      <div className="max-w-[180px] truncate">
                        {[order.shipping_city, order.shipping_state].filter(Boolean).join(", ") || "-"}
                      </div>
                    </td>
                    <td className="hidden p-4 md:table-cell"><Status label={paymentStatus || "pending_payment"} /></td>
                    <td className="hidden p-4 md:table-cell"><Status label={current} /></td>
                    <td className="hidden p-4 text-slate-400 md:table-cell">{updatedAt ? new Date(updatedAt).toLocaleString() : "-"}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <select
                          value={providerKey}
                          onChange={(event) =>
                            setSelectedFulfillmentProviderByOrder((prev) => ({ ...prev, [order.id]: event.target.value }))
                          }
                          className="h-9 rounded-xl border border-slate-700 bg-slate-900 px-2 text-xs"
                        >
                          {fulfillmentProviderOptions.map((option) => (
                            <option key={option.key} value={option.key} disabled={option.key === "printify" && !isPrintifyReady}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                        <button
                          onClick={() => handleSendToFulfillment(order)}
                          disabled={!canSend || fulfillmentSavingOrderId === order.id || (providerKey === "printify" && !isPrintifyReady)}
                          className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-bold hover:border-emerald-500 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {fulfillmentSavingOrderId === order.id ? "Sending..." : "Send to Fulfillment"}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {fulfillmentMessage && <div className="mt-3 text-sm text-slate-300">{fulfillmentMessage}</div>}
      </Card>
      </div>
      </div>

      <div className="md:hidden">
        <button
          type="button"
          onClick={() => toggleMobileSection("fulfillmentJobs")}
          className="w-full rounded-2xl border border-slate-800 bg-slate-950 px-4 py-2 text-left text-sm font-bold"
        >
          Fulfillment Jobs {mobileOpenSections.fulfillmentJobs ? "−" : "+"}
        </button>
      </div>
      <div className={`${mobileOpenSections.fulfillmentJobs ? "block" : "hidden"} md:block`}>
      <Card title="Fulfillment Jobs">
        <div className="space-y-3 md:hidden">
          {fulfillmentJobs.length === 0 && (
            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4 text-sm text-slate-400">No fulfillment jobs yet.</div>
          )}
          {fulfillmentJobs.map((job) => (
            <div key={job.id} className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-mono text-xs font-bold text-slate-200 break-all">{shortId(job.order_id)}</div>
                  <div className="mt-1 text-sm text-slate-300">Provider: {job.provider_key || "-"}</div>
                </div>
                <Status label={job.status || "queued"} />
              </div>
              <div className="mt-3 space-y-1 text-xs text-slate-300">
                <div><span className="text-slate-400">External:</span> <span className="font-mono break-all">{job.external_fulfillment_id || "-"}</span></div>
                <div><span className="text-slate-400">Created:</span> {job.created_at ? new Date(job.created_at).toLocaleString() : "-"}</div>
                <div className="break-words text-orange-300">{job.error || "-"}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="hidden w-full max-w-full overflow-x-auto rounded-2xl border border-slate-800 md:block">
          <table className="min-w-[900px] w-full text-left text-sm">
            <thead className="bg-slate-950 text-slate-400">
              <tr>{["Order Id", "Provider", "Status", "External Id", "Created", "Error"].map((h) => <th key={h} className="p-4">{h}</th>)}</tr>
            </thead>
            <tbody>
              {fulfillmentJobs.length === 0 && (
                <tr className="border-t border-slate-800">
                  <td className="p-4 text-slate-400" colSpan={6}>No fulfillment jobs yet.</td>
                </tr>
              )}
              {fulfillmentJobs.map((job) => (
                <tr key={job.id} className="border-t border-slate-800">
                  <td className="p-4 font-mono text-xs text-slate-300 break-all">{job.order_id}</td>
                  <td className="p-4">{job.provider_key || "-"}</td>
                  <td className="p-4"><Status label={job.status || "queued"} /></td>
                  <td className="p-4 font-mono text-xs text-slate-300 break-all">{job.external_fulfillment_id || "-"}</td>
                  <td className="p-4 text-slate-400">{job.created_at ? new Date(job.created_at).toLocaleString() : "-"}</td>
                  <td className="p-4 text-orange-300 break-words">{job.error || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      </div>

      <Card title="Manual CashApp Payouts (Processed Weekly)">
        <div className="grid gap-4 md:grid-cols-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-xs text-slate-400">Total earned</div>
            <div className="text-xl font-black">{money(payoutSummary.totalEarned)}</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-xs text-slate-400">Available balance</div>
            <div className="text-xl font-black">{money(payoutSummary.available)}</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-xs text-slate-400">Pending payouts</div>
            <div className="text-xl font-black">{money(payoutSummary.pending)}</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
            <div className="text-xs text-slate-400">Paid payouts</div>
            <div className="text-xl font-black">{money(payoutSummary.paid)}</div>
          </div>
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-[1fr_auto]">
          <input
            value={cashappTag}
            onChange={(event) => setCashappTag(event.target.value)}
            placeholder="$YourCashAppTag"
            className="h-11 rounded-2xl border border-slate-800 bg-slate-950 px-4 text-sm outline-none focus:border-emerald-500"
          />
          <button
            type="button"
            onClick={handleRequestPayout}
            disabled={payoutSaving}
            className="rounded-2xl bg-emerald-500 px-4 py-2 text-sm font-black text-black disabled:opacity-60"
          >
            {payoutSaving ? "Submitting..." : "Request Payout"}
          </button>
        </div>
        {payoutMessage && <div className="mt-2 text-sm text-slate-300">{payoutMessage}</div>}
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Total Earned">
          <div className="text-3xl font-black">{money(earningsSummary.total)}</div>
        </Card>
        <Card title="Pending Earnings">
          <div className="text-3xl font-black">{money(earningsSummary.pending)}</div>
        </Card>
        <Card title="Available Earnings">
          <div className="text-3xl font-black">{money(earningsSummary.available)}</div>
        </Card>
      </div>

      <div className="md:hidden">
        <button
          type="button"
          onClick={() => toggleMobileSection("earnings")}
          className="w-full rounded-2xl border border-slate-800 bg-slate-950 px-4 py-2 text-left text-sm font-bold"
        >
          Earnings Ledger {mobileOpenSections.earnings ? "−" : "+"}
        </button>
      </div>
      <div className={`${mobileOpenSections.earnings ? "block" : "hidden"} md:block`}>
      <Card title="Earnings">
        <div className="w-full max-w-full overflow-x-auto rounded-2xl border border-slate-800">
          <table className="min-w-[640px] w-full text-left text-sm">
            <thead className="bg-slate-950 text-slate-400">
              <tr>{["Order", "Amount", "Status", "Payout", "Date"].map((h) => <th key={h} className="p-4">{h}</th>)}</tr>
            </thead>
            <tbody>
              {earnings.length === 0 && (
                <tr className="border-t border-slate-800">
                  <td className="p-4 text-slate-400" colSpan={5}>No earnings yet.</td>
                </tr>
              )}
              {earnings.map((row) => (
                <tr key={row.id} className="border-t border-slate-800">
                  <td className="p-4 font-mono text-xs text-slate-300 break-all">{row.order_id}</td>
                  <td className="p-4 font-bold">{money(row.amount)}</td>
                  <td className="p-4"><Status label={row.status || "pending"} /></td>
                  <td className="p-4"><Status label={row.payout_status || "unpaid"} /></td>
                  <td className="p-4 text-slate-400">{row.created_at ? new Date(row.created_at).toLocaleDateString() : "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      </div>

      <Card title="Payout Requests">
        <div className="w-full max-w-full overflow-x-auto rounded-2xl border border-slate-800">
          <table className="min-w-[760px] w-full text-left text-sm">
            <thead className="bg-slate-950 text-slate-400">
              <tr>{["Amount", "Method", "CashApp", "Status", "Requested", "Processed"].map((h) => <th key={h} className="p-4">{h}</th>)}</tr>
            </thead>
            <tbody>
              {payouts.length === 0 && (
                <tr className="border-t border-slate-800">
                  <td className="p-4 text-slate-400" colSpan={6}>No payout requests yet.</td>
                </tr>
              )}
              {payouts.map((row) => (
                <tr key={row.id} className="border-t border-slate-800">
                  <td className="p-4 font-bold">{money(row.amount)}</td>
                  <td className="p-4">{row.method || "cashapp"}</td>
                  <td className="p-4">{row.cashapp_tag || "-"}</td>
                  <td className="p-4"><Status label={row.status || "pending"} /></td>
                  <td className="p-4 text-slate-400">{row.created_at ? new Date(row.created_at).toLocaleDateString() : "-"}</td>
                  <td className="p-4 text-slate-400">{row.processed_at ? new Date(row.processed_at).toLocaleDateString() : "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function ProductCard({ userId, product, onToggleActive, onSaveEdit, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [form, setForm] = useState({
    name: product.name || "",
    product_type: product.product_type || "T-Shirt",
    price: String(product.price ?? 0),
    image_url: product.image_url || "",
    design_image_url: product.design_image_url || "",
    design_storage_path: product.design_storage_path || "",
    design_original_filename: product.design_original_filename || "",
    print_area: product.print_area || "front",
  });
  const [imageUpauthLoading, setImageUpauthLoading] = useState(false);

  useEffect(() => {
    setForm({
      name: product.name || "",
      product_type: product.product_type || "T-Shirt",
      price: String(product.price ?? 0),
      image_url: product.image_url || "",
      design_image_url: product.design_image_url || "",
      design_storage_path: product.design_storage_path || "",
      design_original_filename: product.design_original_filename || "",
      print_area: product.print_area || "front",
    });
  }, [product.id, product.name, product.product_type, product.price, product.image_url, product.design_image_url, product.design_storage_path, product.design_original_filename, product.print_area]);

  const onChange = (field) => (event) => {
    setForm((prev) => ({ ...prev, [field]: event.target.value }));
  };

  const submitEdit = async (event) => {
    event.preventDefault();
    if (!form.name.trim()) {
      setError("Product name is required.");
      return;
    }
    try {
      setSaving(true);
      setError("");
      setSuccess("");
      const defaults = getPrintifyDefaultsForType(form.product_type);
      await onSaveEdit(product.id, {
        name: form.name.trim(),
        product_type: form.product_type,
        price: form.price,
        profit: "0",
        image_url: form.image_url || null,
        design_image_url: form.design_image_url || null,
        design_storage_path: form.design_storage_path || null,
        design_original_filename: form.design_original_filename || null,
        printify_variant_id: defaults.variantId,
        printify_blueprint_id: defaults.blueprintId,
        printify_print_provider_id: defaults.printProviderId,
        print_area: form.print_area || "front",
        is_printify_ready: Boolean(getPrintifyReadiness({ ...form, ...defaults }).ready),
      });
      setSuccess("Saved.");
      setEditing(false);
    } catch (err) {
      setError(err?.message || "Unable to save product.");
    } finally {
      setSaving(false);
    }
  };

  const onUploadImage = async (event) => {
    const file = event.target.files?.[0];
    if (!file || !userId) return;
    try {
      setImageUpauthLoading(true);
      setError("");
      const uploaded = await uploadProductImage(userId, file, { bucket: "product-designs", productRef: product.id || "temp" });
      setForm((prev) => ({
        ...prev,
        image_url: uploaded.publicUrl,
        design_image_url: uploaded.publicUrl,
        design_storage_path: uploaded.storagePath,
        design_original_filename: uploaded.originalFilename || "",
      }));
    } catch (err) {
      setError(err?.message || "Unable to upload image.");
    } finally {
      setImageUpauthLoading(false);
      event.target.value = "";
    }
  };

  return (
    <motion.div whileHover={{ scale: 1.02 }} className="max-w-full overflow-hidden rounded-3xl border border-slate-800 bg-[#111827] p-4">
      <MockProduct type={product.product_type} imageUrl={product.image_url} designUrl={product.design_image_url} />
      <div className="mt-4 flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-black">{product.name}</h3>
          <p className="text-sm text-slate-400">{money(product.price)} · Est. Pilot Earnings {money(Number(product.price || 0) * 0.9)}</p>
        </div>
        <button onClick={onToggleActive} className="flex-none rounded p-1">
          {product.active ? <ToggleRight className="h-6 w-6 text-emerald-400" /> : <ToggleLeft className="h-6 w-6 text-slate-500" />}
        </button>
      </div>
      <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
        <span>{product.sales_count || 0} sold</span>
        <div className="flex gap-3">
          <button onClick={() => setEditing((prev) => !prev)} className="font-bold text-orange-400">{editing ? "Close" : "Edit"}</button>
          <button onClick={onDelete} className="font-bold text-orange-400">Delete</button>
        </div>
      </div>
      {editing && (
        <form onSubmit={submitEdit} className="mt-3 space-y-2 text-sm">
          <input value={form.name} onChange={onChange("name")} className="h-10 w-full rounded-xl border border-slate-800 bg-slate-950 px-3 outline-none focus:border-emerald-500" />
          <select value={form.product_type} onChange={onChange("product_type")} className="h-10 w-full rounded-xl border border-slate-800 bg-slate-950 px-3 outline-none focus:border-emerald-500">
            {productTypes.map((type) => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
          <input type="number" min="0" step="0.01" value={form.price} onChange={onChange("price")} className="h-10 w-full rounded-xl border border-slate-800 bg-slate-950 px-3 outline-none focus:border-emerald-500" />
          <div className="text-xs text-slate-400">Earnings are auto-calculated as 90% of subtotal.</div>
          <input value={form.design_image_url} onChange={onChange("design_image_url")} placeholder="Design image URL (optional fallback)" className="h-10 w-full rounded-xl border border-slate-800 bg-slate-950 px-3 outline-none focus:border-emerald-500" />
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-2 text-xs text-slate-300">
            <div className="font-bold text-slate-200">Printify readiness</div>
            {(() => {
              const ready = getPrintifyReadiness(form);
              return (
                <div className="mt-1 space-y-1">
                  <div>{ready.typeSupported ? "✓" : "✗"} Product type supported</div>
                  <div>{ready.hasPrice ? "✓" : "✗"} Retail price set</div>
                  <div>{ready.hasDesign ? "✓" : "✗"} Design image added</div>
                  <div>{ready.defaultsConfigured ? "✓" : "✗"} Platform Printify defaults configured</div>
                  <div className={`pt-1 font-bold ${ready.ready ? "text-emerald-300" : "text-orange-300"}`}>
                    {ready.ready ? "Ready for Printify" : (ready.hasDesign ? "Platform Printify defaults not configured" : "Missing design image")}
                  </div>
                </div>
              );
            })()}
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-2">
            <label className="text-xs font-bold text-slate-400">Upload logo/design</label>
            <input type="file" accept=".png,.jpg,.jpeg,.svg,.webp,image/png,image/jpeg,image/svg+xml,image/webp" onChange={onUploadImage} className="mt-1 text-xs text-slate-300" />
            {imageUpauthLoading && <div className="mt-1 text-xs text-slate-400">UpauthLoading image...</div>}
            {form.design_image_url && <img src={form.design_image_url} alt="Design image" className="mt-2 h-20 w-full max-w-full rounded-lg border border-slate-700 object-cover sm:w-20" />}
          </div>
          {error && <div className="text-xs text-orange-300">{error}</div>}
          {success && <div className="text-xs text-emerald-300">{success}</div>}
          <button disabled={saving} className="rounded-xl bg-emerald-500 px-3 py-2 text-xs font-black text-black disabled:opacity-60">
            {saving ? "Saving..." : "Save"}
          </button>
        </form>
      )}
    </motion.div>
  );
}

function MockProduct({ type, imageUrl, designUrl }) {
  if (imageUrl) {
    return (
      <div className="relative h-44 overflow-hidden rounded-3xl border border-slate-800 bg-slate-950">
        <img src={imageUrl} alt={type || "Product"} className="h-full w-full max-w-full object-cover" />
        {designUrl && (
          <div className="absolute inset-0 flex items-center justify-center">
            <img src={designUrl} alt="Design overlay" className="max-h-20 max-w-20 rounded-md bg-black/40 p-1 object-contain" />
          </div>
        )}
        {!designUrl && (
          <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-300">Upload Design</div>
        )}
        <div className="absolute bottom-3 left-3 rounded-full bg-slate-950/80 px-3 py-1 text-xs text-slate-300">{type}</div>
      </div>
    );
  }
  return (
    <div className="relative flex h-44 items-center justify-center overflow-hidden rounded-3xl bg-gradient-to-br from-slate-800 to-slate-950">
      <Package className="h-24 w-24 text-slate-700" />
      <div className="absolute rounded-xl border border-emerald-400/50 bg-black/60 px-4 py-2 text-center text-xs font-black text-emerald-400 shadow-[0_0_25px_rgba(34,197,94,0.2)]">
        {designUrl ? <img src={designUrl} alt="Design overlay" className="h-10 w-10 object-contain" /> : <>Upload<br />Design</>}
      </div>
      <div className="absolute bottom-3 left-3 rounded-full bg-slate-950/80 px-3 py-1 text-xs text-slate-300">{type}</div>
    </div>
  );
}

function Status({ label }) {
  const normalized = String(label || "").toLowerCase();
  const color =
    normalized === "delivered" || normalized === "paid" || normalized === "complete" || normalized === "available"
      ? "text-emerald-400"
      : normalized === "processing"
        ? "text-amber-300"
        : normalized === "shipped"
          ? "text-sky-400"
          : "text-slate-300";
  return <span className={`rounded-full bg-slate-950 px-3 py-1 text-xs font-bold ${color}`}>{label}</span>;
}

function ContentPage({ user }) {
  const [videos, setVideos] = useState([]);
  const [authLoadingVideos, setAuthLoadingVideos] = useState(false);
  const [videosError, setVideosError] = useState("");
  const [videoUrlInput, setVideoUrlInput] = useState("");
  const [addingVideo, setAddingVideo] = useState(false);
  const [addVideoError, setAddVideoError] = useState("");

  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;

    async function load() {
      setAuthLoadingVideos(true);
      setVideosError("");
      try {
        const rows = await getVideos(user.id);
        if (!cancelled) setVideos(rows);
      } catch (err) {
        if (!cancelled) setVideosError(err?.message || "Unable to load videos.");
      } finally {
        if (!cancelled) setAuthLoadingVideos(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const handleAddVideo = async (event) => {
    event.preventDefault();
    if (!user?.id || addingVideo) return;

    setAddVideoError("");
    const youtubeVideoId = extractYouTubeId(videoUrlInput);
    if (!youtubeVideoId) {
      setAddVideoError("Invalid YouTube URL.");
      return;
    }

    try {
      setAddingVideo(true);
      const created = await createVideo({
        user_id: user.id,
        title: `New Video (${youtubeVideoId})`,
        youtube_url: videoUrlInput.trim(),
        youtube_video_id: youtubeVideoId,
        featured: false,
      });
      setVideos((prev) => [created, ...prev]);
      setVideoUrlInput("");
    } catch (err) {
      setAddVideoError(err?.message || "Unable to add video.");
    } finally {
      setAddingVideo(false);
    }
  };

  const handleToggleFeatured = async (video) => {
    const prevFeatured = Boolean(video.featured);
    setVideos((prev) =>
      prev.map((item) => (item.id === video.id ? { ...item, featured: !prevFeatured } : item))
    );

    try {
      const saved = await updateVideo(video.id, { featured: !prevFeatured });
      setVideos((prev) => prev.map((item) => (item.id === video.id ? saved : item)));
    } catch (err) {
      setVideos((prev) =>
        prev.map((item) => (item.id === video.id ? { ...item, featured: prevFeatured } : item))
      );
      setVideosError(err?.message || "Unable to update video.");
    }
  };

  const handleDeleteVideo = async (videoId) => {
    if (!window.confirm("Delete this video?")) return;
    const snapshot = videos;
    setVideos((prev) => prev.filter((item) => item.id !== videoId));
    try {
      await deleteVideo(videoId);
    } catch (err) {
      setVideos(snapshot);
      setVideosError(err?.message || "Unable to delete video.");
    }
  };

  return (
    <div className="space-y-6">
      <Card title="Add YouTube Video">
        <form onSubmit={handleAddVideo} className="flex flex-col gap-3 sm:flex-row">
          <input
            value={videoUrlInput}
            onChange={(event) => setVideoUrlInput(event.target.value)}
            className="h-12 flex-1 rounded-2xl border border-slate-800 bg-slate-950 px-4 outline-none focus:border-emerald-500"
            placeholder="Paste YouTube video URL"
          />
          <button disabled={addingVideo} className="rounded-2xl bg-emerald-500 px-5 py-3 font-black text-black disabled:opacity-60">
            {addingVideo ? "Adding..." : "Add Video"}
          </button>
        </form>
        {addVideoError && <div className="mt-3 text-sm text-orange-300">{addVideoError}</div>}
        {videosError && <div className="mt-3 text-sm text-orange-300">{videosError}</div>}
      </Card>
      {authLoadingVideos ? (
        <div className="rounded-3xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">Loading videos...</div>
      ) : videos.length === 0 ? (
        <div className="rounded-3xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">
          No videos yet. Add your first video.
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {videos.map((video, index) => (
            <VideoCard
              key={video.id}
              video={video}
              index={index}
              onToggleFeatured={handleToggleFeatured}
              onDelete={handleDeleteVideo}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function VideoCard({ video, index, onToggleFeatured, onDelete }) {
  return (
    <motion.div whileHover={{ y: -3 }} className="overflow-hidden rounded-3xl border border-slate-800 bg-[#111827]">
      <div className="relative aspect-video bg-gradient-to-br from-slate-800 via-slate-950 to-black">
        <iframe
          className="h-full w-full"
          src={`https://www.youtube.com/embed/${video.youtube_video_id}`}
          title={video.title}
          authLoading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          referrerPolicy="strict-origin-when-cross-origin"
          allowFullScreen
        />
        <div className="absolute left-3 top-3 rounded-full bg-black/70 px-3 py-1 text-xs font-bold">Video {index + 1}</div>
      </div>
      <div className="p-4">
        <div className="font-black">{video.title}</div>
        <div className="mt-2 flex items-center justify-between text-sm text-slate-400"><span>-- views</span><span className={video.featured ? "text-emerald-400" : "text-slate-500"}>{video.featured ? "Featured" : "Hidden"}</span></div>
        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={() => onToggleFeatured(video)}
            className="rounded-xl border border-slate-700 px-3 py-2 text-xs font-bold hover:border-emerald-500"
          >
            {video.featured ? "Unfeature" : "Feature"}
          </button>
          <button
            onClick={() => onDelete(video.id)}
            className="rounded-xl border border-slate-700 px-3 py-2 text-xs font-bold text-orange-300 hover:border-orange-500"
          >
            Delete
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function MessagesPage({ user, initialThreadId, onUnreadCountRefresh }) {
  const [threads, setThreads] = useState([]);
  const [selectedThreadId, setSelectedThreadId] = useState("");
  const [messages, setMessages] = useState([]);
  const [authLoadingThreads, setAuthLoadingThreads] = useState(false);
  const [authLoadingMessages, setAuthLoadingMessages] = useState(false);
  const [threadsError, setThreadsError] = useState("");
  const [messagesError, setMessagesError] = useState("");
  const [composerValue, setComposerValue] = useState("");
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState("");

  const selectedThread = useMemo(
    () => threads.find((thread) => thread.id === selectedThreadId) || null,
    [threads, selectedThreadId]
  );

  const loadThreads = async (preferredThreadId) => {
    if (!user?.id) return;
    setAuthLoadingThreads(true);
    setThreadsError("");
    try {
      const rows = await getThreads(user.id);
      setThreads(rows);
      const targetThreadId = preferredThreadId || selectedThreadId;
      if (targetThreadId && rows.some((thread) => thread.id === targetThreadId)) {
        setSelectedThreadId(targetThreadId);
      } else {
        setSelectedThreadId(rows[0]?.id || "");
      }
    } catch (err) {
      setThreadsError(err?.message || "Unable to load messages.");
    } finally {
      setAuthLoadingThreads(false);
      if (onUnreadCountRefresh) await onUnreadCountRefresh();
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    loadThreads(initialThreadId);
  }, [user?.id, initialThreadId]);

  useEffect(() => {
    if (!selectedThreadId || !user?.id) {
      setMessages([]);
      return;
    }

    let cancelled = false;
    async function loadThreadMessages() {
      setAuthLoadingMessages(true);
      setMessagesError("");
      try {
        const rows = await getMessages(selectedThreadId);
        if (!cancelled) setMessages(rows);
        await markThreadRead(selectedThreadId, user.id);
        if (onUnreadCountRefresh) await onUnreadCountRefresh();
        if (!cancelled) {
          setMessages((prev) =>
            prev.map((message) =>
              message.sender_user_id !== user.id && !message.read_at
                ? { ...message, read_at: new Date().toISOString() }
                : message
            )
          );
          setThreads((prev) =>
            prev.map((thread) =>
              thread.id === selectedThreadId ? { ...thread, unread_count: 0 } : thread
            )
          );
        }
      } catch (err) {
        if (!cancelled) setMessagesError(err?.message || "Unable to load thread messages.");
      } finally {
        if (!cancelled) setAuthLoadingMessages(false);
      }
    }

    loadThreadMessages();
    return () => {
      cancelled = true;
    };
  }, [selectedThreadId, user?.id]);

  const onSend = async () => {
    if (!selectedThreadId || !user?.id || sending) return;
    setSendError("");
    try {
      setSending(true);
      await sendMessage(selectedThreadId, user.id, composerValue);
      const recipientUserId = selectedThread?.other_user_id;
      if (recipientUserId) {
        triggerMessageEmailNotification({
          recipient_user_id: recipientUserId,
          sender_user_id: user.id,
          thread_id: selectedThreadId,
        }).catch((emailErr) => {
          console.warn("Message email notification failed:", emailErr?.message || emailErr);
        });
      }
      setComposerValue("");
      const refreshed = await getMessages(selectedThreadId);
      setMessages(refreshed);
      await loadThreads(selectedThreadId);
      if (onUnreadCountRefresh) await onUnreadCountRefresh();
    } catch (err) {
      setSendError(err?.message || "Unable to send message.");
    } finally {
      setSending(false);
    }
  };

  const onComposerKeyDown = (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
      event.preventDefault();
      onSend();
    }
  };

  return (
    <div className="grid min-h-[640px] overflow-hidden rounded-3xl border border-slate-800 bg-[#111827] lg:grid-cols-[320px_1fr]">
      <div className="border-b border-slate-800 lg:border-b-0 lg:border-r">
        <div className="flex items-center justify-between border-b border-slate-800 p-4">
          <div className="font-black">Inbox</div>
          <button
            onClick={() => loadThreads(selectedThreadId || initialThreadId)}
            className="rounded-xl border border-slate-700 px-3 py-1 text-xs font-bold hover:border-emerald-500"
          >
            Refresh
          </button>
        </div>
        {threadsError && <div className="border-b border-slate-800 p-4 text-sm text-orange-300">{threadsError}</div>}
        {authLoadingThreads ? (
          <div className="p-4 text-sm text-slate-300">Loading messages...</div>
        ) : threads.length === 0 ? (
          <div className="p-4 text-sm text-slate-300">No messages yet.</div>
        ) : (
          threads.map((thread) => (
            <button
              key={thread.id}
              onClick={() => setSelectedThreadId(thread.id)}
              className={`flex w-full items-center gap-3 border-b border-slate-800 p-4 text-left hover:bg-slate-900 ${
                selectedThreadId === thread.id ? "bg-slate-900" : ""
              }`}
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 font-black text-emerald-400">
                {(thread.other_label || "P").charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-bold">
                    <span className="truncate">{thread.other_label}</span>
                    {thread.unread_count > 0 && <span className="h-2 w-2 rounded-full bg-orange-400" />}
                  </div>
                  <div className="text-xs text-slate-500">{formatMessageTime(thread.last_activity_at)}</div>
                </div>
                <div className="truncate text-sm text-slate-400">{thread.last_message?.body || "No messages yet."}</div>
              </div>
            </button>
          ))
        )}
      </div>
      <div className="flex flex-col">
        <div className="flex items-center justify-between border-b border-slate-800 p-4">
          <div className="font-black">{selectedThread?.other_label || "Conversation"}</div>
          {selectedThreadId && (
            <button
              onClick={async () => {
                setAuthLoadingMessages(true);
                setMessagesError("");
                try {
                  const rows = await getMessages(selectedThreadId);
                  setMessages(rows);
                  await markThreadRead(selectedThreadId, user.id);
                  if (onUnreadCountRefresh) await onUnreadCountRefresh();
                } catch (err) {
                  setMessagesError(err?.message || "Unable to refresh thread.");
                } finally {
                  setAuthLoadingMessages(false);
                }
              }}
              className="text-sm font-bold text-orange-400"
            >
              Refresh Thread
            </button>
          )}
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          {messagesError && <div className="rounded-2xl bg-orange-500/10 p-3 text-sm text-orange-300">{messagesError}</div>}
          {!selectedThreadId ? (
            <div className="text-sm text-slate-400">No messages yet.</div>
          ) : authLoadingMessages ? (
            <div className="text-sm text-slate-400">Loading thread...</div>
          ) : messages.length === 0 ? (
            <div className="text-sm text-slate-400">No messages yet.</div>
          ) : (
            messages.map((message) => (
              <ChatBubble
                key={message.id}
                text={message.body}
                time={formatMessageTime(message.created_at)}
                own={message.sender_user_id === user?.id}
              />
            ))
          )}
        </div>

        <div className="border-t border-slate-800 p-4">
          <div className="flex gap-3">
            <textarea
              value={composerValue}
              onChange={(event) => setComposerValue(event.target.value)}
              onKeyDown={onComposerKeyDown}
              maxLength={MAX_MESSAGE_LENGTH}
              className="h-12 min-h-12 flex-1 resize-none rounded-2xl bg-slate-950 px-4 py-3 text-sm outline-none focus:ring-1 focus:ring-emerald-500"
              placeholder={selectedThreadId ? "Type message..." : "Select a conversation to start messaging."}
              disabled={!selectedThreadId || sending}
            />
            <button
              onClick={onSend}
              disabled={!selectedThreadId || sending}
              className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500 text-black disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
            <span>Max {MAX_MESSAGE_LENGTH} characters. Ctrl/Cmd+Enter to send.</span>
            <span>{composerValue.trim().length}/{MAX_MESSAGE_LENGTH}</span>
          </div>
          {sendError && <div className="mt-2 text-sm text-orange-300">{sendError}</div>}
        </div>
      </div>
    </div>
  );
}

function ChatBubble({ text, own, time }) {
  return (
    <div className={`flex ${own ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-md rounded-3xl px-4 py-3 text-sm ${own ? "bg-emerald-500 text-black" : "bg-slate-950 text-slate-100"}`}>
        <div>{text}</div>
        {time && <div className={`mt-2 text-[11px] ${own ? "text-black/70" : "text-slate-400"}`}>{time}</div>}
      </div>
    </div>
  );
}

function PublicStorefrontPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [authLoading, setAuthLoading] = useState(true);
  const [error, setError] = useState("");
  const [videosError, setVideosError] = useState("");
  const [pilot, setPilot] = useState(null);
  const [products, setProducts] = useState([]);
  const [videos, setVideos] = useState([]);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [buyMessage, setBuyMessage] = useState("");
  const [checkingOutProductId, setCheckingOutProductId] = useState("");
  const [messageStatus, setMessageStatus] = useState("");
  const [creatingThread, setCreatingThread] = useState(false);
  const [showLoginCta, setShowLoginCta] = useState(false);
  const [followMessage, setFollowMessage] = useState("");
  const [youtubeVideos, setYoutubeVideos] = useState([]);

  useEffect(() => {
    if (!slug) return;

    let cancelled = false;
    async function loadStorefront() {
      setAuthLoading(true);
      setError("");
      setVideosError("");
      setPilot(null);
      setProducts([]);
      setVideos([]);
      setYoutubeVideos([]);
      setSelectedVideo(null);
      setSelectedProduct(null);

      try {
        const pilotData = await getPilotBySlug(slug);
        if (!pilotData) {
          if (!cancelled) setPilot(null);
          return;
        }

        const activeProducts = await getActiveProductsByUserId(pilotData.user_id);
        let pilotVideos = [];
        try {
          pilotVideos = await getVideosByUserId(pilotData.user_id, 8);
        } catch (videoErr) {
          if (!cancelled) {
            setVideosError(videoErr?.message || "Unable to load videos right now.");
          }
        }
        if (!cancelled) {
          setPilot(pilotData);
          setProducts(activeProducts);
          setVideos(pilotVideos);
          const ytAccount = (pilotData.social_accounts || []).find((row) => row.platform === "youtube");
          if (ytAccount?.external_id) {
            try {
              const latest = await getChannelVideos(ytAccount.external_id, 6);
              if (!cancelled) setYoutubeVideos(latest);
            } catch {
              if (!cancelled) setYoutubeVideos([]);
            }
          }
        }
      } catch (err) {
        if (!cancelled) setError(err?.message || "Unable to load storefront.");
      } finally {
        if (!cancelled) setAuthLoading(false);
      }
    }

    loadStorefront();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  if (supabaseConfigError) {
    return <SetupScreen title="Storefront Setup Error" error={supabaseConfigError} />;
  }

  if (authLoading) {
    return <SetupScreen title="Loading Storefront" message="Fetching pilot profile and active merch." authLoading />;
  }

  if (error) {
    return <SetupScreen title="Storefront Error" error={error} />;
  }

  if (!pilot) {
    return (
      <SetupScreen
        title="Pilot Not Found"
        message="The requested pilot storefront does not exist or is no longer available."
      />
    );
  }

  const publicSocials = getPilotPublicSocials(pilot);
  const youtubeAccount = publicSocials.find((row) => row.platform === "youtube");
  const featuredVideos = videos.filter((video) => Boolean(video.featured) && video.youtube_video_id).slice(0, 3);
  const remainingVideos = videos.filter((video) => video.youtube_video_id && !featuredVideos.some((item) => item.id === video.id));
  const hasVideos = featuredVideos.length > 0 || remainingVideos.length > 0;
  const activeVideo = selectedVideo && remainingVideos.some((video) => video.id === selectedVideo.id) ? selectedVideo : null;
  const startMessageThread = async () => {
    if (!pilot?.user_id || creatingThread) return;
    setMessageStatus("");
    setShowLoginCta(false);
    setCreatingThread(true);
    try {
      const { data, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      const currentUserId = data?.session?.user?.id;
      if (!currentUserId) {
        setMessageStatus("Create an account or log in to message this pilot.");
        setShowLoginCta(true);
        return;
      }
      if (currentUserId === pilot.user_id) {
        setMessageStatus("This is your storefront.");
        return;
      }
      const thread = await createOrGetThread(pilot.user_id, currentUserId);
      navigate(`/dashboard/messages?thread=${thread.id}`);
    } catch (err) {
      setMessageStatus(err?.message || "Unable to start conversation.");
    } finally {
      setCreatingThread(false);
    }
  };

  const startCheckout = async (product) => {
    if (!product?.id || checkingOutProductId) return;
    setBuyMessage("");
    setCheckingOutProductId(product.id);
    try {
      const checkoutUrl = await createCheckoutSession({
        product_id: product.id,
        quantity: 1,
        slug: pilot?.slug || slug || "",
      });
      window.location.href = checkoutUrl;
    } catch (err) {
      setBuyMessage(err?.message || "Unable to start checkout.");
      setCheckingOutProductId("");
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F14] text-slate-100">
      <header className="border-b border-slate-800 bg-[#0B0F14]/95 px-4 py-4 backdrop-blur md:px-6">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-emerald-500 font-black text-black">Q</div>
            <div className="text-lg font-black tracking-tight">QuadRoster Storefront</div>
          </Link>
          <Link to="/dashboard" className="rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 text-sm font-bold hover:border-emerald-500">
            Dashboard
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 md:px-8">
        <section className="overflow-hidden rounded-3xl border border-slate-800 bg-[#111827] shadow-xl shadow-black/20">
          <div className="h-40 bg-gradient-to-r from-emerald-600/25 via-slate-900 to-orange-500/20">
            {pilot.banner_url ? (
              <img src={pilot.banner_url} alt={`${pilot.pilot_name} banner`} className="h-full w-full object-cover" />
            ) : null}
          </div>
          <div className="p-5">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
              <div className="flex items-end gap-4">
                <div className="flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl border border-slate-700 bg-slate-950 text-2xl font-black text-emerald-400">
                  {pilot.avatar_url ? (
                    <img src={pilot.avatar_url} alt={pilot.pilot_name} className="h-full w-full object-cover" />
                  ) : (
                    (pilot.pilot_name || "P").charAt(0).toUpperCase()
                  )}
                </div>
                <div>
                  <h1 className="text-3xl font-black tracking-tight">{pilot.pilot_name}</h1>
                  {pilot.location && (
                    <div className="mt-1 flex items-center gap-1 text-sm text-slate-400">
                      <MapPin className="h-4 w-4" /> {pilot.location}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={startMessageThread}
                  disabled={creatingThread}
                  className="rounded-2xl border border-slate-800 bg-slate-900 px-4 py-2 text-sm font-bold hover:border-emerald-500 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {creatingThread ? "Starting..." : "Message Pilot"}
                </button>
                <button
                  onClick={() => setFollowMessage("Follow feature coming soon.")}
                  className="rounded-2xl bg-emerald-500 px-4 py-2 text-sm font-black text-black hover:bg-emerald-400"
                >
                  Follow
                </button>
              </div>
            </div>
            <p className="mt-4 max-w-3xl text-sm text-slate-300">{pilot.bio || "No bio added yet."}</p>
            {messageStatus && <div className="mt-3 rounded-2xl bg-slate-900 p-3 text-sm text-orange-300">{messageStatus}</div>}
            {followMessage && <div className="mt-3 rounded-2xl bg-slate-900 p-3 text-sm text-emerald-300">{followMessage}</div>}
            {showLoginCta && (
              <div className="mt-3 flex flex-wrap gap-2">
                <Link to="/login" className="rounded-2xl border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-bold hover:border-emerald-500">
                  Log In
                </Link>
                <Link to="/login" className="rounded-2xl bg-orange-500 px-4 py-2 text-sm font-black text-black hover:bg-orange-400">
                  Create Account
                </Link>
              </div>
            )}
            <div className="mt-4 flex flex-wrap gap-2 text-sm">
              {publicSocials.map((social) => (
                <a
                  key={`${pilot.user_id}-${social.platform}`}
                  href={social.profile_url}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-slate-700 px-3 py-1 text-slate-300 hover:border-emerald-500"
                >
                  {socialLabel(social.platform)}
                </a>
              ))}
            </div>
          </div>
        </section>

        <section className="mt-6">
          {youtubeAccount && (
            <div className="mb-6 rounded-3xl border border-slate-800 bg-[#111827] p-5 shadow-xl shadow-black/20">
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-2xl border border-slate-700 bg-slate-950">
                  {youtubeAccount.avatar_url ? (
                    <img src={youtubeAccount.avatar_url} alt={youtubeAccount.display_name || "YouTube"} className="h-full w-full object-cover" />
                  ) : (
                    <PlayCircle className="h-6 w-6 text-emerald-400" />
                  )}
                </div>
                <div>
                  <div className="text-sm text-slate-400">YouTube Channel</div>
                  <div className="text-lg font-black">{youtubeAccount.display_name || youtubeAccount.handle || "YouTube"}</div>
                  <div className="text-xs text-slate-400">
                    {youtubeAccount.follower_count != null ? `${Number(youtubeAccount.follower_count).toLocaleString()} subscribers` : "Subscribers unavailable"}
                    {" · "}
                    {youtubeAccount.video_count != null ? `${Number(youtubeAccount.video_count).toLocaleString()} videos` : "Video count unavailable"}
                  </div>
                </div>
              </div>
              {youtubeVideos.length > 0 ? (
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {youtubeVideos.slice(0, 6).map((video) => (
                    <a
                      key={video.id}
                      href={video.url}
                      target="_blank"
                      rel="noreferrer"
                      className="group overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/50 hover:border-emerald-500"
                    >
                      <div className="aspect-video overflow-hidden bg-slate-950">
                        {video.thumbnail ? (
                          <img src={video.thumbnail} alt={video.title} className="h-full w-full object-cover transition group-hover:scale-[1.02]" />
                        ) : (
                          <div className="flex h-full items-center justify-center text-slate-500">No thumbnail</div>
                        )}
                      </div>
                      <div className="p-3 text-sm font-bold line-clamp-2">{video.title}</div>
                    </a>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-slate-400">No public YouTube videos loaded.</div>
              )}
            </div>
          )}
          {videosError && (
            <div className="rounded-2xl border border-orange-500/30 bg-orange-500/10 p-4 text-sm text-orange-300">
              {videosError}
            </div>
          )}

          {!videosError && featuredVideos.length > 0 && (
            <>
              <h2 className="text-xl font-black">Featured Videos</h2>
              <div className="mt-4 grid gap-4 lg:grid-cols-2">
                {featuredVideos.map((video, index) => (
                  <div
                    key={video.id}
                    className={index === 0 ? "overflow-hidden rounded-3xl border border-slate-800 bg-[#111827] p-3 lg:col-span-2" : "overflow-hidden rounded-3xl border border-slate-800 bg-[#111827] p-3"}
                  >
                    <div className="aspect-video overflow-hidden rounded-2xl border border-slate-700 bg-slate-950">
                      <iframe
                        className="h-full w-full"
                        src={`https://www.youtube.com/embed/${video.youtube_video_id}`}
                        title={video.title || "Featured video"}
                        authLoading="lazy"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        referrerPolicy="strict-origin-when-cross-origin"
                        allowFullScreen
                      />
                    </div>
                    <h3 className="mt-3 text-base font-black">{video.title || "Untitled video"}</h3>
                  </div>
                ))}
              </div>
            </>
          )}

          {!videosError && hasVideos && (
            <>
              <h2 className="mt-6 text-xl font-black">Videos</h2>
              {remainingVideos.length === 0 ? (
                <div className="mt-4 rounded-2xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">
                  This pilot has no additional videos right now.
                </div>
              ) : (
                <>
                  <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    {remainingVideos.map((video) => (
                      <button
                        key={video.id}
                        onClick={() => setSelectedVideo(video)}
                        className="overflow-hidden rounded-3xl border border-slate-800 bg-[#111827] p-3 text-left hover:border-emerald-500"
                      >
                        <div className="aspect-video overflow-hidden rounded-2xl border border-slate-700 bg-slate-950">
                          <img
                            src={`https://img.youtube.com/vi/${video.youtube_video_id}/hqdefault.jpg`}
                            alt={video.title || "Video thumbnail"}
                            authLoading="lazy"
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <h3 className="mt-3 truncate text-sm font-black">{video.title || "Untitled video"}</h3>
                        <div className="mt-1 text-xs text-slate-400">Click to expand</div>
                      </button>
                    ))}
                  </div>

                  {activeVideo && (
                    <section className="mt-6 rounded-3xl border border-slate-800 bg-[#111827] p-5 shadow-xl shadow-black/20">
                      <div className="mb-4 flex items-center justify-between">
                        <h3 className="text-lg font-black">{activeVideo.title || "Video"}</h3>
                        <button onClick={() => setSelectedVideo(null)} className="text-sm font-bold text-orange-400">Close</button>
                      </div>
                      <div className="aspect-video overflow-hidden rounded-2xl border border-slate-700 bg-slate-950">
                        <iframe
                          className="h-full w-full"
                          src={`https://www.youtube.com/embed/${activeVideo.youtube_video_id}`}
                          title={activeVideo.title || "Video"}
                          authLoading="lazy"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                          referrerPolicy="strict-origin-when-cross-origin"
                          allowFullScreen
                        />
                      </div>
                    </section>
                  )}
                </>
              )}
            </>
          )}

          {!videosError && !hasVideos && (
            <div className="rounded-2xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">
              This pilot hasn’t shared any videos yet.
            </div>
          )}
        </section>

        <section className="mt-6">
          <h2 className="text-xl font-black">Merch</h2>
          {products.length === 0 ? (
            <div className="mt-4 rounded-2xl border border-slate-800 bg-[#111827] p-4 text-sm text-slate-300">
              This pilot has not listed merch yet.
            </div>
          ) : (
            <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {products.map((product) => (
                <motion.div key={product.id} whileHover={{ scale: 1.02 }} className="rounded-3xl border border-slate-800 bg-[#111827] p-4">
                  <MockProduct type={product.product_type} imageUrl={product.image_url} />
                  <div className="mt-4">
                    <h3 className="font-black">{product.name}</h3>
                    <p className="text-sm text-slate-400">{product.product_type} · {money(product.price)}</p>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => {
                        setSelectedProduct(product);
                        setBuyMessage("");
                        requestAnimationFrame(() => {
                          const el = document.getElementById("storefront-product-detail");
                          if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
                        });
                      }}
                      className="flex-1 rounded-xl border border-slate-700 px-3 py-2 text-xs font-bold hover:border-emerald-500"
                    >
                      View Product
                    </button>
                    <button
                      onClick={() => startCheckout(product)}
                      disabled={Boolean(checkingOutProductId)}
                      className="flex-1 rounded-xl bg-emerald-500 px-3 py-2 text-xs font-black text-black hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {checkingOutProductId === product.id ? "Redirecting..." : "Buy Now"}
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </section>

        {buyMessage && <div className="mt-4 rounded-2xl bg-slate-900 p-3 text-sm text-orange-300">{buyMessage}</div>}

        {selectedProduct && (
          <section id="storefront-product-detail" className="mt-6 rounded-3xl border border-slate-800 bg-[#111827] p-5 shadow-xl shadow-black/20">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-black">Product Detail</h3>
              <button onClick={() => setSelectedProduct(null)} className="text-sm font-bold text-orange-400">Close</button>
            </div>
            <div className="grid gap-5 md:grid-cols-[320px_1fr]">
              <MockProduct type={selectedProduct.product_type} imageUrl={selectedProduct.image_url} />
              <div>
                <h4 className="text-2xl font-black">{selectedProduct.name}</h4>
                <p className="mt-1 text-sm text-slate-400">{selectedProduct.product_type}</p>
                <p className="mt-3 text-xl font-black text-emerald-400">{money(selectedProduct.price)}</p>
                <button
                  onClick={() => startCheckout(selectedProduct)}
                  disabled={Boolean(checkingOutProductId)}
                  className="mt-4 rounded-2xl bg-emerald-500 px-5 py-3 text-sm font-black text-black hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {checkingOutProductId === selectedProduct.id ? "Redirecting..." : "Buy Now"}
                </button>
              </div>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

function OrderSuccessPage() {
  const { orderId } = useParams();
  const location = useLocation();
  const slug = new URLSearchParams(location.search).get("slug") || "";
  const storefrontHref = slug ? `/p/${slug}` : "/pilots";
  const [order, setOrder] = useState(null);
  const [authLoadingOrder, setAuthLoadingOrder] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function loadOrder() {
      if (!orderId) {
        setAuthLoadingOrder(false);
        return;
      }
      try {
        const next = await fetchOrderSuccess(orderId);
        if (!cancelled) setOrder(next);
      } catch (err) {
        console.warn("Unable to load order success details:", err?.message || err);
      } finally {
        if (!cancelled) setAuthLoadingOrder(false);
      }
    }
    loadOrder();
    return () => {
      cancelled = true;
    };
  }, [orderId]);

  return (
    <div className="min-h-screen bg-[#0B0F14] text-slate-100">
      <PublicNav />
      <main className="mx-auto max-w-3xl px-4 py-10 md:px-8">
        <section className="rounded-3xl border border-slate-800 bg-[#111827] p-6 shadow-xl shadow-black/20">
          <div className="flex items-center gap-3 text-emerald-400">
            <CheckCircle2 className="h-6 w-6" />
            <h1 className="text-2xl font-black">Payment Complete</h1>
          </div>
          <p className="mt-3 text-sm text-slate-300">Your payment succeeded and your order has been submitted.</p>
          <div className="mt-4 space-y-1 text-sm text-slate-300">
            <div>Session: <span className="font-mono text-xs text-slate-200 break-all">{orderId}</span></div>
            {authLoadingOrder ? (
              <div className="text-slate-400">Loading order details...</div>
            ) : (
              <>
                <div>Product: <span className="font-bold">{order?.product_name || "-"}</span></div>
                <div>Total Paid: <span className="font-bold">{money(order?.total ?? order?.amount)}</span></div>
                <div>Buyer: {order?.buyer_name || order?.buyer_email || "-"}</div>
                <div>Shipping: {formatShippingAddress(order) || "-"}</div>
              </>
            )}
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Link to={storefrontHref} className="rounded-2xl border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-bold hover:border-emerald-500">
              Back to Storefront
            </Link>
            <Link to="/dashboard" className="rounded-2xl bg-emerald-500 px-4 py-2 text-sm font-black text-black hover:bg-emerald-400">
              Open Dashboard
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
}


function AdminPayoutsPage() {
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");

  const isAdmin = parseAdminEmails(session?.user);

  useEffect(() => {
    if (!supabase) {
      setAuthLoading(false);
      return;
    }

    let cancelled = false;

    async function init() {
      const { data } = await supabase.auth.getSession();
      if (cancelled) return;

      const currentSession = data?.session || null;
      setSession(currentSession);

      if (!currentSession?.user) {
        setAuthLoading(false);
        return;
      }

      if (!parseAdminEmails(currentSession.user)) {
        setAuthLoading(false);
        return;
      }

      try {
        const payouts = await getAllPayouts();
        const emailMap = await getPilotEmails(payouts.map(p => p.pilot_user_id));

        const enriched = payouts.map(p => ({
          ...p,
          pilot_email: emailMap.get(p.pilot_user_id) || "-"
        }));

        setRows(enriched);
      } catch (err) {
        setError(err?.message || "Failed to load payouts");
      } finally {
        setAuthLoading(false);
      }
    }

    init();

    return () => {
      cancelled = true;
    };
  }, []);

    if (authLoading) return <div style={{padding:20}}>Loading...</div>;
  if (!session?.user) return <div style={{padding:20}}>Please log in</div>;
  if (!isAdmin) return <div style={{padding:20}}>Access Denied</div>;

    async function onMarkPaid(id) {
    console.log("MARK PAID CLICKED:", id);
    try {
      await processAdminPayout(id, "mark_paid");
      // refresh data
      const payouts = await getAllPayouts();
      const emailMap = await getPilotEmails(payouts.map(p => p.pilot_user_id));
      setRows(payouts.map(p => ({
        ...p,
        pilot_email: emailMap.get(p.pilot_user_id) || "-"
      })));
    } catch (err) {
      console.error("MARK PAID ERROR:", err);
      setError(err?.message || "Unable to mark payout paid");
    }
  }

return (
    <div style={{padding:20}}>
      <h2>Admin Payouts</h2>

      {error && <div style={{color:"red"}}>{error}</div>}

      {rows.length === 0 ? (
        <div>No payouts found</div>
      ) : (
        <table border="1" cellPadding="6">
          <thead>
            <tr>
              <th>Pilot</th>
              <th>CashApp</th>
              <th>Amount</th>
              <th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(row => (
              <tr key={row.id}>
                <td>{row.pilot_email}</td>
                <td>{row.cashapp_tag}</td>
                <td>${row.amount}</td>
                <td>{row.status}</td>
<td>
  <button className="ml-2 rounded-lg bg-emerald-500 px-3 py-1 text-sm font-bold text-black hover:bg-emerald-400" onClick={() => { console.log("CLICK", row.id); onMarkPaid(row.id); }}>
    Mark Paid
  </button>
</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}


function SettingsPage({ user, pilotProfile, onSave, onNavigate }) {
  const [form, setForm] = useState(() => ({
    pilot_name: pilotProfile?.pilot_name || "",
    slug: pilotProfile?.slug || "",
    bio: pilotProfile?.bio || "",
    location: pilotProfile?.location || "",
    avatar_url: pilotProfile?.avatar_url || "",
    banner_url: pilotProfile?.banner_url || "",
    cashapp_tag: pilotProfile?.cashapp_tag || "",
  }));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [socialAccounts, setSocialAccounts] = useState([]);
  const [socialDrafts, setSocialDrafts] = useState({});
  const [socialSavingPlatform, setSocialSavingPlatform] = useState("");
  const [socialError, setSocialError] = useState("");
  const [socialSuccess, setSocialSuccess] = useState("");

  useEffect(() => {
    setForm({
      pilot_name: pilotProfile?.pilot_name || "",
      slug: pilotProfile?.slug || "",
      bio: pilotProfile?.bio || "",
      location: pilotProfile?.location || "",
      avatar_url: pilotProfile?.avatar_url || "",
      banner_url: pilotProfile?.banner_url || "",
      cashapp_tag: pilotProfile?.cashapp_tag || "",
    });
  }, [pilotProfile]);

  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;
    async function loadSocials() {
      try {
        const rows = await getSocialAccounts(user.id);
        if (!cancelled) {
          setSocialAccounts(rows);
          const nextDrafts = {};
          for (const platform of SOCIAL_PLATFORM_CONFIG) {
            const account = rows.find((row) => row.platform === platform.key);
            nextDrafts[platform.key] = account?.profile_url || "";
          }
          setSocialDrafts(nextDrafts);
        }
      } catch (err) {
        if (!cancelled) setSocialError(err?.message || "Unable to load social accounts.");
      }
    }
    loadSocials();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const onChange = (field) => (event) => {
    const rawValue = event.target.value;
    const value = field === "slug" ? rawValue.toLowerCase().replace(/\s+/g, "-") : rawValue;
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const submit = async (event) => {
    event.preventDefault();
    setSuccess("");
    setError("");

    const slugError = validateSlug(form.slug);
    if (slugError) {
      setError(slugError);
      return;
    }
    if (form.cashapp_tag && !validateCashAppTag(form.cashapp_tag)) {
      setError("CashApp tag must start with $ and use 2-30 letters, numbers, or underscores.");
      return;
    }

    try {
      setSaving(true);
      await onSave(form);
      setSuccess("Profile saved.");
    } catch (err) {
      setError(err?.message || "Unable to save profile.");
    } finally {
      setSaving(false);
    }
  };

  const onSocialDraftChange = (platform) => (event) => {
    const value = event.target.value;
    setSocialDrafts((prev) => ({ ...prev, [platform]: value }));
  };

  const connectSocial = async (platform) => {
    if (!user?.id || socialSavingPlatform) return;
    try {
      setSocialSavingPlatform(platform);
      setSocialError("");
      setSocialSuccess("");
      await upsertSocialAccount(user.id, platform, socialDrafts[platform] || "");
      const rows = await getSocialAccounts(user.id);
      setSocialAccounts(rows);
      setSocialSuccess(`${socialLabel(platform)} connected.`);
    } catch (err) {
      setSocialError(err?.message || "Unable to connect social account.");
    } finally {
      setSocialSavingPlatform("");
    }
  };

  const disconnectSocial = async (platform) => {
    if (!user?.id || socialSavingPlatform) return;
    try {
      setSocialSavingPlatform(platform);
      setSocialError("");
      setSocialSuccess("");
      await deleteSocialAccount(user.id, platform);
      const rows = await getSocialAccounts(user.id);
      setSocialAccounts(rows);
      setSocialDrafts((prev) => ({ ...prev, [platform]: "" }));
      setSocialSuccess(`${socialLabel(platform)} disconnected.`);
    } catch (err) {
      setSocialError(err?.message || "Unable to disconnect social account.");
    } finally {
      setSocialSavingPlatform("");
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
      <Card title="Profile Info">
        <form onSubmit={submit}>
          <FormField label="Pilot Name" value={form.pilot_name} onChange={onChange("pilot_name")} />
          <FormField label="Slug" value={form.slug} onChange={onChange("slug")} />
          <FormField label="Bio" value={form.bio} onChange={onChange("bio")} textarea />
          <FormField label="Location" value={form.location} onChange={onChange("location")} />
          <FormField label="Avatar URL" value={form.avatar_url} onChange={onChange("avatar_url")} />
          <FormField label="Banner URL" value={form.banner_url} onChange={onChange("banner_url")} />
          <FormField label="CashApp Tag" value={form.cashapp_tag} onChange={onChange("cashapp_tag")} />
          {error && <div className="mb-3 rounded-2xl bg-orange-500/10 p-3 text-sm text-orange-300">{error}</div>}
          {success && <div className="mb-3 rounded-2xl bg-emerald-500/10 p-3 text-sm text-emerald-300">{success}</div>}
          <button
            disabled={saving}
            className="mt-2 rounded-2xl bg-emerald-500 px-5 py-3 font-black text-black disabled:cursor-not-allowed disabled:opacity-60"
          >
            {saving ? "Saving..." : "Save Profile"}
          </button>
        </form>
      </Card>
      <div className="space-y-6">
        <Card title="Social Connections">
          <p className="mb-3 text-xs text-slate-400">
            Add public profile links for your channels. Later: sync latest YouTube uploads into videos table.
          </p>
          <div className="space-y-3">
            {SOCIAL_PLATFORM_CONFIG.map((platform) => {
              const account = socialAccounts.find((row) => row.platform === platform.key);
              const connected = Boolean(account);
              return (
                <div key={platform.key} className="rounded-2xl border border-slate-800 bg-slate-950/40 p-3">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-slate-300" />
                      <div className="font-bold">{platform.label}</div>
                      {account?.verified ? <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-black text-emerald-300">Verified</span> : null}
                    </div>
                    <div className={`text-xs ${connected ? "text-emerald-400" : "text-slate-500"}`}>
                      {connected ? "Connected" : "Not connected"}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input
                      value={socialDrafts[platform.key] || ""}
                      onChange={onSocialDraftChange(platform.key)}
                      placeholder={`Enter ${platform.label} profile URL`}
                      className="h-10 flex-1 rounded-xl border border-slate-800 bg-slate-950 px-3 text-sm outline-none focus:border-emerald-500"
                    />
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => connectSocial(platform.key)}
                        disabled={socialSavingPlatform === platform.key}
                        className="rounded-xl bg-emerald-500 px-3 py-2 text-xs font-black text-black disabled:opacity-60"
                      >
                        {socialSavingPlatform === platform.key ? "Saving..." : connected ? "Save" : "Connect"}
                      </button>
                      <button
                        type="button"
                        onClick={() => disconnectSocial(platform.key)}
                        disabled={!connected || socialSavingPlatform === platform.key}
                        className="rounded-xl border border-slate-700 px-3 py-2 text-xs font-bold disabled:opacity-50"
                      >
                        Disconnect
                      </button>
                    </div>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-500">
                    Last synced: {account?.last_synced_at ? new Date(account.last_synced_at).toLocaleString() : "Never"}
                  </div>
                </div>
              );
            })}
          </div>
          {socialError && <div className="mt-3 rounded-2xl bg-orange-500/10 p-3 text-sm text-orange-300">{socialError}</div>}
          {socialSuccess && <div className="mt-3 rounded-2xl bg-emerald-500/10 p-3 text-sm text-emerald-300">{socialSuccess}</div>}
        </Card>
        <Card title="Subscription">
          <div className="rounded-2xl border border-orange-500/40 bg-orange-500/10 p-4"><div className="font-black text-orange-400">Free Plan</div><div className="mt-1 text-sm text-slate-400">5 products, standard fees, basic analytics.</div></div>
          <button onClick={() => onNavigate?.("settings")} className="mt-4 w-full rounded-2xl bg-orange-500 px-5 py-3 font-black text-black">Upgrade to Pro</button>
        </Card>
        <Card title="Legal Status">
          <div className="flex items-center gap-3 text-sm"><Shield className="h-5 w-5 text-emerald-400" /> Logo rights confirmed</div>
          <div className="mt-3 flex items-center gap-3 text-sm"><AlertCircle className="h-5 w-5 text-orange-400" /> Terms accepted Apr 30, 2026</div>
        </Card>
      </div>
    </div>
  );
}

function FormField({ label, value, textarea, onChange }) {
  return (
    <label className="mb-4 block">
      <div className="mb-2 text-sm font-bold text-slate-300">{label}</div>
      {textarea ? (
        <textarea
          value={value}
          onChange={onChange}
          className="min-h-28 w-full rounded-2xl border border-slate-800 bg-slate-950 p-4 outline-none focus:border-emerald-500"
        />
      ) : (
        <input
          value={value}
          onChange={onChange}
          className="h-12 w-full rounded-2xl border border-slate-800 bg-slate-950 px-4 outline-none focus:border-emerald-500"
        />
      )}
    </label>
  );
}

function SocialRow({ icon: Icon, label, status, muted }) {
  return <div className="flex items-center justify-between border-b border-slate-800 py-3 last:border-b-0"><div className="flex items-center gap-3"><Icon className="h-5 w-5" /><span className="font-bold">{label}</span></div><span className={muted ? "text-sm text-slate-500" : "text-sm text-emerald-400"}>{status}</span></div>;
}

export default App;
